#include "tftp.h"
#include "ui_tftp.h"

Tftp::Tftp(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Tftp)
{
    ui->setupUi(this);
}

Tftp::~Tftp()
{
    delete ui;
}
