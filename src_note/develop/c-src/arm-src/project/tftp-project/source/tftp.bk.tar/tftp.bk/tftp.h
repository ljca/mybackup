#ifndef TFTP_H
#define TFTP_H

#include <QMainWindow>

namespace Ui {
class Tftp;
}

class Tftp : public QMainWindow
{
    Q_OBJECT

public:
    explicit Tftp(QWidget *parent = 0);
    ~Tftp();

private:
    Ui::Tftp *ui;
};

#ifndef PORT
#define PORT 69
#endif

#ifndef BUFSIZE
#define BUFSIZE 4096
#endif

#endif // TFTP_H
