#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <arpa/inet.h>
#include "tftp.h"

int download_file(char *file,char *host,int sfd)
{
    if(NULL == file || sfd = -1) return -1;
    FILE *fd;
    if(NULL == (fd = fopen(file,"w"))){
        return -1;
    }
    struct sockaddr_in server;
    bzero(&server,sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);
    inet_pton(AF_INET,host,&server.sin_addr);
    char buf[BUFSIZE] = "";
    if(-1 == sendto(sfd,buf,strlen(buf),0,(struct sockaddr *)&server,sizeof(server))){
        return -1;
    }
    while(1){
        ssize_t len;
        bzero(&buf,BUFSIZE);
        len = recvfrom(sfd,buf,strlen(buf),0,(struct sockaddr *)&server,&len);
        if(len == -1) break;
        fwrite(buf,1,strlen(buf),fd);
    }
    fclose(fd);
    close(sfd);
}
