#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <sys/ioctl.h>

#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/udp.h>

#define PROT 6013
#define MAX_SIZE 512

void show_ip_header(struct iphdr *h, int nbytes)
{
	printf("\n\n-------------  ip: %d bytes ---------------\n", nbytes);
	printf(" version: %d  header_size: %d \n",
			h->version, h->ihl);
	printf(" tos: %d,  total length: %d\n", 
			h->tos, ntohs(h->tot_len));
	printf(" id: %d, frag_flags: %d, frag_off: %d\n", ntohs(h->id),
			(ntohs(h->frag_off) & 0x7), 
				ntohs((h->frag_off)) >> 12);
	printf(" ttl: %d, protocol: %d, check: %d\n", 
			h->ttl, h->protocol, ntohs(h->check));	
	printf(" src: %s, dst: %s\n", inet_ntoa(h->saddr), 
				inet_ntoa(h->daddr));				
}

int main(int argc, char **argv)
{
	int sockfd, ret;
	struct sockaddr_in selfaddr;
	char buf[MAX_SIZE];
	

	sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
	if (sockfd < 0) {
		perror("socket");	
		return 0;
	}
				
	while(1) {
		ret = read(sockfd, buf, 512);	
		if (ret < 0) {
			perror("read");
			return 0;
		}
		
		show_ip_header(buf, ret );
	}
	close(sockfd);	
	return 0;
}




