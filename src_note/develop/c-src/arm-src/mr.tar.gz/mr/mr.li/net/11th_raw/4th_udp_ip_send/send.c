#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <sys/ioctl.h>

#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/udp.h>

#define PROT 6013
#define MAX_SIZE 512

unsigned short check_sum(unsigned short *addr,int len) 
{ 

	register int nleft = len; 
	register int sum=0; 
	register short *w=addr; 
	short answer=0; 

	while( nleft > 1 ) { 
		sum+=*w++; 
		nleft-=2; 
	} 

	if( nleft == 1 )  { 
		*(unsigned char *)(&answer)=*(unsigned char *)w; 
		sum+=answer; 
	} 

	sum=(sum>>16)+(sum&0xffff); 
	sum+=(sum>>16); 
	answer=~sum; 

	return(answer); 
} 

void build_udp_header(int buf, int len, short src_port, short dst_port )
{	
	char *temp;
	struct udphdr *p;

	temp = malloc(len + 8);
	memcpy(temp + 8, *((char **)buf), len);
	free(*(char **)buf);
	*(char **)buf = temp;

	p = temp;	
	
	p->source = htons(src_port);
	p->dest = htons(dst_port);
	p->len  = htons(len + 8);
	p->check = 0;
	p->check = check_sum(p, 20);
}

void build_ip_header(char **buf,  int len, char *src_addr, char *dst_addr)
{
	struct iphdr *p;
	char *temp = malloc(len	+ 20);
	memcpy(temp + 20, *buf, len);
	free(*buf);
	*buf = temp;	
	p = temp;	

	p->version = 4;
	p->ihl = 5; // warning: unit 4 bytes == Double Word
	p->tos = 0;	
	p->tot_len = htons(len + 20);	
	p->id = htons(0);
	p->frag_off = htons(0);
	p->ttl   = 64;
	p->protocol = IPPROTO_UDP;
	p->saddr  = inet_addr(src_addr);
	p->daddr  = inet_addr(dst_addr);
	p->check   = 0;	

	p->check = check_sum(p, 20);
}

int main(int argc, char **argv)
{
	int sockfd, ret;
	struct sockaddr_in selfaddr;
	char *buf = NULL; 
	struct sockaddr_in  conaddr;	

	sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
	if (sockfd < 0) {
		perror("socket");	
		return 0;
	}
				
	buf = malloc(MAX_SIZE);	
	strcpy(buf, "client 1 write\n");
	build_udp_header(&buf, MAX_SIZE, 6013, 6013);
	
	build_ip_header(&buf, MAX_SIZE + 8, "192.168.1.221", "192.168.1.221");
	
	{
		int onoff = 1;
		int len = 4;
		ret = setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &onoff, 4 );
		if (ret < 0) {
			perror("setsockopt");
		}

		ret = getsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &onoff, &len );
		if (ret < 0) {
			perror("getsockopt IP_HDRINCL");
		}
		printf("getsockopt IP_HDRINCL : %d\n", onoff);
	}

	bzero(&conaddr, sizeof(conaddr));
#if 0
	conaddr.sin_family = AF_INET;
	conaddr.sin_port = htons(PROT);
	conaddr.sin_addr.s_addr = inet_addr("10.168.1.221");
#endif

	ret = sendto(sockfd, buf, MAX_SIZE + 8 + 20, 0, 
				&conaddr, sizeof(conaddr));
	if (ret < 0) {
		perror("sendto");
	}
	
	free(buf);
	close(sockfd);	
	return 0;
}




