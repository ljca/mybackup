#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <unistd.h>

#define PORT 6103
int main(int argc, char **argv)
{
	int sockfd, confd, ret;
	struct sockaddr_in  selfaddr, conaddr;
	int  conlen;
	char buf[512];

	bzero(&selfaddr, sizeof(selfaddr));
	bzero(&conaddr, sizeof(conaddr));

	/*
	IPPROTO_TCP  IPPROTO_UDP  IPPROTO_IP IPPROTO_IGMP         
	*/
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) {
		perror("socket");
		return 0;
	}

	int onoff;
	int len = 4;
	/*
		           SOL_SOCKET   SO_REUSEADDR
					SO_BROADCAST
					SO_RCVBUF
					SO_SNDBUF
		--------------------------------------
			   IPPROTO_IP   IP_HDRINCL
					IP_RECVIF
	 */	

	getsockopt(sockfd, SOL_SOCKET , SO_REUSEADDR, &onoff, &len);
	printf("onoff = %d\n", onoff);

	setsockopt(sockfd, SOL_SOCKET , SO_REUSEADDR, &onoff, len);

	selfaddr.sin_family = AF_INET;
	selfaddr.sin_port   = htons(PORT);
	selfaddr.sin_addr.s_addr = htonl(INADDR_ANY);

	ret = bind(sockfd, &selfaddr, sizeof(selfaddr));
	if (ret < 0) {
		perror("bind");
		return 0;
	}

	ret = listen(sockfd, 0);
	if (ret < 0) {
		perror("listen");
		return 0;
	}
	
	conlen = sizeof(conaddr);

	while(1) {
		confd = accept(sockfd, &conaddr, &conlen);
		if (confd < 0) {
			perror("accept");
			return 0;
		}

		if (fork() == 0) {
			if (conaddr.sin_port = 63)
			close(sockfd);
			write(confd, "hello\n", 6);		
			close(confd);
			exit(0);
		}		
		close(confd);
	}
	close(sockfd);
	return 0;
}



