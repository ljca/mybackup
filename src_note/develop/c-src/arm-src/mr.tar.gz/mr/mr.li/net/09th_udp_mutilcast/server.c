#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define PROT 6013

#define MAX_SIZE 512
int main(int argc, char **argv)
{
	int sockfd, ret, sender_len;
	struct sockaddr_in selfaddr, sender;
	char buf[MAX_SIZE];
	
	sockfd = socket(AF_INET, SOCK_DGRAM, 0 );
	if (sockfd < 0) {
		perror("socket");	
		return 0;
	}
	

	selfaddr.sin_family = AF_INET;
	selfaddr.sin_port = htons(PROT);
	selfaddr.sin_addr.s_addr = htonl(INADDR_ANY); 

	bind(sockfd, &selfaddr, sizeof(selfaddr));
	if (ret < 0) {
		perror("bind");
		return 0;
	}	

	{
		struct ip_mreq command; 	
		int onoff = 1;
		ret = setsockopt(sockfd, IPPROTO_IP, 
			IP_MULTICAST_LOOP, &onoff, sizeof(onoff));	

		if (ret < 0) {
			perror("setsockopt broadcast option");
		}
		command.imr_multiaddr.s_addr = inet_addr("224.0.0.9");
		command.imr_interface.s_addr = htonl(INADDR_ANY);
	
		ret = setsockopt( sockfd, IPPROTO_IP, IP_ADD_MEMBERSHIP,
			  &command, sizeof(command));		
		if (ret < 0) {
			perror("setsockopt");
		}

		ret = setsockopt( sockfd, IPPROTO_IP, IP_DROP_MEMBERSHIP,
			  &command, sizeof(command));		
		if (ret < 0) {
			perror("setsockopt");
		}
	
	}

	
	sender_len = sizeof(sender);
	ret = recvfrom( sockfd, buf, MAX_SIZE, 0, &sender, &sender_len);
	if (ret < 0) {
		perror("read");		
		return 0;
	}

	printf("server 1: read %d bytes: %s\n", ret, buf);

	ret = connect(sockfd, &sender, sender_len);	
	if (ret < 0) {
		perror("connect");	
		return 0;
	}
	printf("sender: %s\n", inet_ntoa(sender.sin_addr.s_addr));
	
	ret = write(sockfd, "server 1 write", 15);
	if (ret < 0) {
		perror("write");
	}
	printf("server 1 write: %d bytes\n", ret);


	//--------------- disconnect ----
	printf("----------- disconnect --------\n");
	sender.sin_family = AF_UNSPEC;
	ret = connect(sockfd, &sender, sender_len);
	if (ret < 0) {
		perror("connect");	
		return 0;
	}

	//----------------- reconnect ------	
	ret = recvfrom( sockfd, buf, MAX_SIZE, 0, &sender, &sender_len);
	if (ret < 0) {
		perror("recvfrom");		
		return 0;
	}
	printf("server 2 read %d bytes: %s\n", ret, buf);

	sender.sin_family = AF_INET;
	ret = connect(sockfd, &sender, sender_len);
	if (ret < 0) {
		perror("connect");	
		return 0;
	}

	ret = write(sockfd, "server 2 write ", 15);
	if (ret < 0) {
		perror("write");
		return 0;
	}
	printf("server 2 write: %d bytes\n", ret);

	ret = read( sockfd, buf, MAX_SIZE);
	if (ret < 0) {
		perror("recvfrom");		
		return 0;
	}
	printf("server 3 read %d bytes: %s\n", ret, buf);
	close(sockfd);	
	return 0;
}



