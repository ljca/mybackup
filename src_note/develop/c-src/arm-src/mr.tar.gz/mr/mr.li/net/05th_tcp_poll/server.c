#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/poll.h>

#define PORT 6103
int main(int argc, char **argv)
{
	int sockfd, confd[3], ret;
	struct sockaddr_in  selfaddr, conaddr;
	int  conlen, i;
	char buf[512];

	bzero(&selfaddr, sizeof(selfaddr));
	bzero(&conaddr, sizeof(conaddr));

	/*
	IPPROTO_TCP  IPPROTO_UDP  IPPROTO_IP IPPROTO_IGMP         
	*/
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) {
		perror("socket");
		return 0;
	}

	int onoff;
	int len = 4;
	/*
		           SOL_SOCKET   SO_REUSEADDR
					SO_BROADCAST
					SO_RCVBUF
					SO_SNDBUF
		--------------------------------------
			   IPPROTO_IP   IP_HDRINCL
					IP_RECVIF
			   
	 */	

	onoff = 1;
	setsockopt(sockfd, SOL_SOCKET , SO_REUSEADDR, &onoff, len);

	getsockopt(sockfd, SOL_SOCKET , SO_REUSEADDR, &onoff, &len);
	printf("onoff = %d\n", onoff);

	selfaddr.sin_family = AF_INET;
	selfaddr.sin_port   = htons(PORT);
	selfaddr.sin_addr.s_addr = htonl(INADDR_ANY);

	ret = bind(sockfd, &selfaddr, sizeof(selfaddr));
	if (ret < 0) {
		perror("bind");
		return 0;
	}

	ret = listen(sockfd, 0);
	if (ret < 0) {
		perror("listen");
		return 0;
	}
	
	conlen = sizeof(conaddr);
	
	for (i = 0; i < 3; i ++) {
		confd[i] = accept(sockfd, &conaddr, &conlen);
		if (confd < 0) {
			perror("accept");
			return 0;
		}
	}	

	int max = 3;
	while(max > 0) {	
		struct pollfd  pollfd[i];
		
		i = 0;
		if (confd[0] != -1) {
			pollfd[i].fd = confd[0];
			pollfd[i].events = POLLIN;	
			i ++;
		}

		if (confd[1] != -1) {
			pollfd[i].fd = confd[1];
			pollfd[i].events = POLLIN;	
			i ++;
		}

		if (confd[1] != -1) {
			pollfd[i].fd = confd[2];
			pollfd[i].events = POLLIN;	
			i ++;
		}

		ret = poll(pollfd, 3, 1000);
		if (ret > 0) {
			for (i = 0; i < max; i ++) {
				if (pollfd[i].revents & POLLIN) {
					read(pollfd[i].fd, buf, 512); 
					printf("read: %s\n", buf);
					max --;
					confd[i] = -1;
				}
			}	
		
		} else if (ret == 0) {
			printf("timeout\n");
		} else { 
			perror("poll");
		}	
	}
	close(confd);
	close(sockfd);
	return 0;
}




