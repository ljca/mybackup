#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <unistd.h>

#define PORT 6103
int main(int argc, char **argv)
{
	int sockfd , ret;
	struct sockaddr_in  conaddr;
	char buf[512];

	if (argc != 2) {
		printf("Usage: %s <ip> \n", argv[0]);
		return 0;
	}

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) {
		perror("socket");
		return 0;
	}

	bzero(&conaddr, sizeof(conaddr));

	conaddr.sin_family = AF_INET;
	conaddr.sin_port   = htons(PORT);
	conaddr.sin_addr.s_addr = inet_addr(argv[1]);

	ret = connect(sockfd, &conaddr, sizeof(conaddr));
	if (ret < 0) {
		perror("connect");
		return 0;
	}

	memset(buf, 0, 512);
	
	read(sockfd, buf, 512);
	printf("client read: %s\n", buf);
	

	close(sockfd);
	return 0;
}



