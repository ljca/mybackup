#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <sys/ioctl.h>

#define PROT 6013

#define MAX_SIZE 512
int main(int argc, char **argv)
{
	int sockfd, ret, sender_len;
	struct sockaddr_in selfaddr;
	char buf[MAX_SIZE];
	
	if (argc < 2) {
		printf("Usage: %s  <ifname>\n", argv[0]);
		return 0;
	}

	sockfd = socket(AF_INET, SOCK_DGRAM, 0 );
	if (sockfd < 0) {
		perror("socket");	
		return 0;
	}
	
	struct ifreq if_info;	
//	strcpy(if_info.ifr_ifrn.ifrn_name, "eth1");
	strcpy(if_info.ifr_name, argv[1]);

	ret = ioctl(sockfd, SIOCGIFADDR, &if_info);
	if (ret < 0) {
		perror("ioctl");
	}
	
	printf("%s :  %s\n", argv[1], 
		inet_ntoa(((struct sockaddr_in *)(&if_info.ifr_addr))->sin_addr.s_addr));
	
	close(sockfd);	
	return 0;
}



