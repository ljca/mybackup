#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <unistd.h>

#define PORT 6103
int main(int argc, char **argv)
{
	int sockfd, confd, ret;
	struct sockaddr_in  selfaddr, conaddr;
	int  conlen;
	char buf[512];

	bzero(&selfaddr, sizeof(selfaddr));
	bzero(&conaddr, sizeof(conaddr));

	/*
	IPPROTO_TCP  IPPROTO_UDP  IPPROTO_IP IPPROTO_IGMP         
	*/
	
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) {
		perror("socket");
		return 0;
	}

	selfaddr.sin_family = AF_INET;
	selfaddr.sin_port   = htons(PORT);
	selfaddr.sin_addr.s_addr = htonl(INADDR_ANY);
//	selfaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	int onoff=1;
	setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &onoff, 4);

	ret = bind(sockfd, &selfaddr, sizeof(selfaddr));
	if (ret < 0) {
		perror("bind");
		return 0;
	}

	ret = listen(sockfd, 0);
	if (ret < 0) {
		perror("listen");
		return 0;
	}
	
	conlen = sizeof(conaddr);

	confd = accept(sockfd, &conaddr, &conlen);
	if (confd < 0) {
		perror("accept");
		return 0;
	}

	printf("end of accept\n");
//	shutdown(confd, SHUT_RD);
//	shutdown(confd, SHUT_WR);

//	write(confd, "hello\n", 6);	
	ret = read(confd, buf, 512);

	printf("server %d bytes read: %s\n", ret, buf);

	close(confd);
	close(sockfd);
	return 0;
}



