#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <sys/ioctl.h>

#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/udp.h>
#include <linux/if_ether.h>

#define PROT 6013
#define MAX_SIZE 512

void print_space(int space)
{
	int i;
	for (i = 0; i < space; i ++)
		printf(" ");
}

void show_app_header(char *buf, short port, int nbytes)
{
	print_space(12);
	printf("------- app %d bytes ---\n", nbytes);
	switch(port)	{
		case 21:
		print_space(12);
		printf("ftp\n");
		break;
		
		case PROT:
		print_space(12);
		printf(buf);
		printf("\n");
		break;
	}
}

void show_udp_header(struct udphdr *h, int nbytes)
{
	print_space(8); 	
	printf("-------- udp %d bytes -------\n", nbytes);
	print_space(8);
	printf(" src port: %d\n", ntohs(h->source));
	print_space(8);
	printf(" dst port: %d\n", ntohs(h->dest));
	print_space(8);
	printf(" totoal length: %d bytes\n", ntohs(h->len));
	print_space(8);
	printf(" check:   %d\n", ntohs(h->check));

	show_app_header((char *)h + 8, ntohs(h->dest), nbytes - 8);
}

void show_ip_header(struct iphdr *h, int nbytes)
{
	print_space(4); 	
	printf("-------------  ip: %d bytes ---------------\n", nbytes);
	print_space(4); 	
	printf(" version: %d  header_size: %d \n",
			h->version, h->ihl);
	print_space(4); 	
	printf(" tos: %d,  total length: %d\n", 
			h->tos, ntohs(h->tot_len));
	print_space(4); 	
	printf(" id: %d, frag_flags: %d, frag_off: %d\n", ntohs(h->id),
			(ntohs(h->frag_off) & 0x7), 
				ntohs((h->frag_off)) >> 12);
	print_space(4); 	
	printf(" ttl: %d, protocol: %d, check: %d\n", 
			h->ttl, h->protocol, ntohs(h->check));	
	print_space(4); 	
	printf(" src: %s, dst: %s\n", inet_ntoa(h->saddr), 
				inet_ntoa(h->daddr));				
	switch(h->protocol) {
		case IPPROTO_UDP:
			show_udp_header((char *)h  + h->ihl * 4, 
					ntohs(h->tot_len) - h->ihl * 4);
		break;
	}	
}

void show_arp_header(struct arphdr *h, int nbytes)
{
	print_space(4);
	printf("-------- arp: %d bytes -----\n", nbytes);
}

void show_eth_header(struct ethhdr *h, int nbytes)
{
	printf("--------------- eth : %d bytes----------\n", nbytes);	
	printf("dst mac: %02x:%02x:%02x:%02x:%02x:%02x\n", 
			h->h_dest[0], h->h_dest[1], h->h_dest[2],
			h->h_dest[3], h->h_dest[4], h->h_dest[5]);
	
	printf("src mac: %02x:%02x:%02x:%02x:%02x:%02x\n", 
			h->h_source[0], h->h_source[1], h->h_source[2],
			h->h_source[3], h->h_source[4], h->h_source[5]);

	switch(ntohs(h->h_proto)) {
		case ETH_P_IP:
			show_ip_header((char *)h + 14, nbytes - 14);
			break;

		case ETH_P_ARP:
			show_arp_header((char *)h + 14, nbytes - 14);
			break;
	}
}

int main(int argc, char **argv)
{
	int sockfd, ret;
	struct sockaddr_in selfaddr;
	char buf[MAX_SIZE];
	

	sockfd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (sockfd < 0) {
		perror("socket");	
		return 0;
	}
				
	while(1) {
		ret = read(sockfd, buf, 512);	
		if (ret < 0) {
			perror("read");
			return 0;
		}
		
		show_eth_header(buf, ret );
		printf("\n\n");
	}
	close(sockfd);	
	return 0;
}




