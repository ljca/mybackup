#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define PROT 6013
#define MAX_SIZE 512

int main(int argc, char **argv)
{
	int sockfd, ret, conaddr_len;
	struct sockaddr_in conaddr;
	char buf[MAX_SIZE];

	if (argc < 2) {
		printf("Usage: %s <ip>\n", argv[0]);
		return 0;
	}
	
	sockfd = socket(AF_INET, SOCK_DGRAM, 0 );
	if (sockfd < 0) {
		perror("socket");	
		return 0;
	}
	
	int onoff = 1;
	ret = setsockopt(sockfd, SOL_SOCKET, 
			SO_BROADCAST, &onoff, sizeof(onoff));	
	if (ret < 0) {
		perror("setsockopt broadcast option");
	}

	conaddr.sin_family = AF_INET;
	conaddr.sin_port = htons(PROT);
	conaddr.sin_addr.s_addr = inet_addr(argv[1]);
	
	ret = connect( sockfd, &conaddr, sizeof(conaddr) );
	if (ret < 0) {
		perror("connect");
		return 0;
	}

	ret = write(sockfd, "client 1 write", 15);
	if (ret < 0) {
		perror("write");
		return 0;
	}	

	printf("client 1 write: %d bytes\n", ret);		

	ret = read(sockfd, buf, MAX_SIZE);
	if (ret < 0) {
		perror("read");
		return 0;
	}

	printf("client 1 read %d bytes: %s\n", ret, buf);

	//-------- disconnect   ------------
	printf("--------- disconnect ---------\n");
	conaddr.sin_family = AF_UNSPEC;
	ret = connect( sockfd, &conaddr, sizeof(conaddr) );
	if (ret < 0) {
		perror("connect");
		return 0;
	}

	//--------- connect other -----------	
	conaddr.sin_family = AF_INET;
	conaddr.sin_port = htons(PROT);
	conaddr.sin_addr.s_addr = inet_addr(argv[1]);
	
	ret = connect( sockfd, &conaddr, sizeof(conaddr) );
	if (ret < 0) {
		perror("connect");
		return 0;
	}
	
	ret = write(sockfd, "client 2 write", 15);
	if (ret < 0) {
		perror("write");
		return 0;
	}	
	printf("client 2 write:  %d bytes \n", ret);

	ret = read(sockfd, buf, MAX_SIZE);
	if (ret < 0) {
		perror("read");
		return 0;
	}

	printf("client 2 read %d bytes: %s\n", ret, buf);

	ret = write(sockfd, "client 3 write", 15);
	if (ret < 0) {
		perror("write");
		return 0;
	}	
	printf("client 3 write:  %d bytes \n", ret);
	close(sockfd);	
	return 0;
}



