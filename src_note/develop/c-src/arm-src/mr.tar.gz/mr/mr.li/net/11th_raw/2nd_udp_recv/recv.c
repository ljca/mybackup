#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <sys/ioctl.h>

#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/udp.h>

#define PROT 6013
#define MAX_SIZE 512

void print_space(int space)
{
	int i;
	for (i = 0; i < space; i ++)
		printf(" ");
}

void show_app_header(char *buf, short port, int nbytes)
{
	print_space(8);
	printf("------- app %d bytes ---\n", nbytes);
	switch(port)	{
		case 21:
		print_space(8);
		printf("ftp\n");
		break;
		
		case PROT:
		print_space(8);
		printf(buf);
		printf("\n");
		break;
	}
}

void show_udp_header(struct udphdr *h, int nbytes)
{
	print_space(4); 	
	printf("-------- udp %d bytes -------\n", nbytes);
	print_space(4);
	printf(" src port: %d\n", ntohs(h->source));
	print_space(4);
	printf(" dst port: %d\n", ntohs(h->dest));
	print_space(4);
	printf(" totoal length: %d bytes\n", ntohs(h->len));
	print_space(4);
	printf(" check:   %d\n", ntohs(h->check));

	show_app_header((char *)h + 8, ntohs(h->dest), nbytes - 8);
}

void show_ip_header(struct iphdr *h, int nbytes)
{
	printf("\n\n-------------  ip: %d bytes ---------------\n", nbytes);
	printf(" version: %d  header_size: %d \n",
			h->version, h->ihl);
	printf(" tos: %d,  total length: %d\n", 
			h->tos, ntohs(h->tot_len));
	printf(" id: %d, frag_flags: %d, frag_off: %d\n", ntohs(h->id),
			(ntohs(h->frag_off) & 0x7), 
				ntohs((h->frag_off)) >> 12);
	printf(" ttl: %d, protocol: %d, check: %d\n", 
			h->ttl, h->protocol, ntohs(h->check));	
	printf(" src: %s, dst: %s\n", inet_ntoa(h->saddr), 
				inet_ntoa(h->daddr));				
	switch(h->protocol) {
		case IPPROTO_UDP:
			show_udp_header((char *)h  + h->ihl * 4, 
					ntohs(h->tot_len) - h->ihl * 4);
		break;
	}	
}

int main(int argc, char **argv)
{
	int sockfd, ret;
	struct sockaddr_in selfaddr;
	char buf[MAX_SIZE];
	

	sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
	if (sockfd < 0) {
		perror("socket");	
		return 0;
	}
				
	while(1) {
		ret = read(sockfd, buf, 512);	
		if (ret < 0) {
			perror("read");
			return 0;
		}
		
		show_ip_header(buf, ret );
	}
	close(sockfd);	
	return 0;
}




