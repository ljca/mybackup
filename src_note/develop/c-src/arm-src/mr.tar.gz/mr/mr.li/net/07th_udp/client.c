#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define PROT 6013
#define MAX_SIZE 512

int main(int argc, char **argv)
{
	int sockfd, ret, conaddr_len;
	struct sockaddr_in conaddr;
	char buf[MAX_SIZE];
	
	sockfd = socket(AF_INET, SOCK_DGRAM, 0 );
	if (sockfd < 0) {
		perror("socket");	
		return 0;
	}
	
	conaddr.sin_family = AF_INET;
	conaddr.sin_port = htons(PROT);
	conaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	ret = sendto(sockfd, "hello udp", 10, 0, &conaddr, sizeof(conaddr));
	if (ret < 0) {
		perror("sendto");
		return 0;
	}	
	
	printf("written: %d bytes\n", ret);	

	conaddr_len = sizeof(conaddr);
	ret = recvfrom(sockfd, buf, MAX_SIZE, 0, &conaddr, &conaddr_len);
	if (ret < 0) {
		perror("recvfrom");
		return 0;
	}

	printf("sender: %s, %d bytes: %s\n", 
		inet_ntoa(conaddr.sin_addr.s_addr), ret, buf);
	close(sockfd);	
	return 0;
}



