#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <sys/ioctl.h>

#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/udp.h>

#define PROT 6013
#define MAX_SIZE 512

void build_udp_header(int buf, int len, short src_port, short dst_port )
{	
	char *temp;
	struct udphdr *p;

	temp = malloc(len + 8);
	memcpy(temp + 8, *((char **)buf), len);
	free(*(char **)buf);
	*(char **)buf = temp;

	p = temp;	
	
	p->source = htons(src_port);
	p->dest = htons(dst_port);
	p->len  = htons(len + 8);
	p->check = 0;
}

int main(int argc, char **argv)
{
	int sockfd, ret;
	struct sockaddr_in selfaddr;
	char *buf = NULL; 
	struct sockaddr_in  conaddr;	

	sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
	if (sockfd < 0) {
		perror("socket");	
		return 0;
	}
				
	buf = malloc(MAX_SIZE);	
	strcpy(buf, "client 1 write\n");
	build_udp_header(&buf, MAX_SIZE, 6013, 6013);
	
	conaddr.sin_family = AF_INET;
	conaddr.sin_port = htons(PROT);
	conaddr.sin_addr.s_addr = inet_addr("192.168.1.221");
	
	ret = sendto(sockfd, buf, MAX_SIZE + 8, 0, &conaddr, sizeof(conaddr));
	if (ret < 0) {
		perror("sendto");
	}
	
	free(buf);
	close(sockfd);	
	return 0;
}




