#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <sys/ioctl.h>

#define PROT 6013

#define MAX_SIZE 512
int main(int argc, char **argv)
{
	int sockfd, ret, sender_len;
	struct sockaddr_in selfaddr;
	char buf[MAX_SIZE];
	int i;
	
	sockfd = socket(AF_INET, SOCK_DGRAM, 0 );
	if (sockfd < 0) {
		perror("socket");	
		return 0;
	}
	
	struct ifconf  all_info;	
	struct ifreq   *p = NULL;
	all_info.ifc_len = 10 * sizeof(struct ifreq);
	all_info.ifc_buf = malloc(all_info.ifc_len);

	ret = ioctl(sockfd, SIOCGIFCONF, &all_info );
	if (ret < 0) {
		perror("ioctl");
	}
	
	for (i = 0; i < (all_info.ifc_len / sizeof(struct ifreq)) ; i ++) {
		p = all_info.ifc_buf + i * sizeof(struct ifreq);

		printf("%s :  %s\n", p->ifr_name, 
		inet_ntoa(((struct sockaddr_in *)(&p->ifr_addr))->sin_addr.s_addr));
	
	}
	
	free(all_info.ifc_buf);
	close(sockfd);	
	return 0;
}



