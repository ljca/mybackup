#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/poll.h>
#include <fcntl.h>

#define PORT 6103
int main(int argc, char **argv)
{
	int sockfd, confd, ret;
	struct sockaddr_in  selfaddr, conaddr;
	int  conlen, i;
	char buf[512];

	bzero(&selfaddr, sizeof(selfaddr));
	bzero(&conaddr, sizeof(conaddr));

	/*
	IPPROTO_TCP  IPPROTO_UDP  IPPROTO_IP IPPROTO_IGMP         
	*/
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) {
		perror("socket");
		return 0;
	}

	int onoff;
	int len = 4;
	onoff = 1;
	setsockopt(sockfd, SOL_SOCKET , SO_REUSEADDR, &onoff, len);

	getsockopt(sockfd, SOL_SOCKET , SO_REUSEADDR, &onoff, &len);
	printf("onoff = %d\n", onoff);

	selfaddr.sin_family = AF_INET;
	selfaddr.sin_port   = htons(PORT);
	selfaddr.sin_addr.s_addr = htonl(INADDR_ANY);

	ret = bind(sockfd, &selfaddr, sizeof(selfaddr));
	if (ret < 0) {
		perror("bind");
		return 0;
	}

	ret = listen(sockfd, 0);
	if (ret < 0) {
		perror("listen");
		return 0;
	}
	
	conlen = sizeof(conaddr);
	
	struct pollfd  *pollfd;
	int num = 1;
	pollfd = malloc(num * sizeof(pollfd));

	while(1)
	{	
		pollfd[0].fd = sockfd;
		pollfd[0].events = POLLIN;
		ret = poll(pollfd, num, -1);
		if (ret > 0) {
			for (i = 0; i < num; i ++) {
				if ((i == 0) && (pollfd[0].revents & POLLIN )) {
					struct pollfd *temp;
					confd = accept(sockfd, &conaddr, &conlen);
					num ++;	
					temp = malloc(num * sizeof(struct pollfd));
					memcpy(temp, pollfd, 
						(num - 1) * sizeof(struct pollfd));
					temp[num - 1].fd = confd;	
					temp[num - 1].events = POLLIN;
					free(pollfd);
					pollfd = temp;
				} else 	if ((i != 0) && (pollfd[i].revents & POLLIN)) {
					read(pollfd[i].fd, buf, 512);
					printf("%d:  %s\n", i, buf); 
				}
			}	
		} else if (ret == 0) {
			printf("time out.\n");
		} else {
			perror("poll");
			return 0;
		}
	}

	free(pollfd);

	close(sockfd);
	return 0;
}




