#include <stdio.h>
#include <memory.h>

struct person {
	int age;	
	int sex;

	person() {
	}

	virtual ~person () {
	}

	virtual void eat(void) = 0; //pure virtual  function
};

struct man : public person {
	int salary;

	void eat(void) {
		printf("man eat\n");
	}
};

//------------
void manager(struct person *p)
{
	p->eat();	
}

int main()
{
	man  zs;	
	person ls;

	//-----------------------
	manager(&ls);	
	
	return 0;
}



