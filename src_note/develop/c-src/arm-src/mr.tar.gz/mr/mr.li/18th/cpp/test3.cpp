
#include <stdio.h>

struct node {
	node *next;

	node (void) {
		printf(" node cons\n");	
	};	
	node (int) {
		printf(" node cons\n");	
	};

	virtual ~node() {
		printf(" node disc\n");
	};		

	virtual  void bark(void) {
		printf(" i am a node.\n");
	}
};

struct  dog  :  public  node {
	int num;
	void bark(void) {
		printf("i am num %d, wang ..\n", this->num);
	}
	
	dog () { printf("dog cons\n"); }
	~dog () { printf("dog disc\n");}
};

int  main(void)
{
	node *p;

	p = new dog;

		
	delete p;
	return 0;
}




