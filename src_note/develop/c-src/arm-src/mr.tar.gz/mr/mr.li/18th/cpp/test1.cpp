
#include <stdio.h>

struct node {
	node *next;

	virtual  void bark(void) = 0; 
};

struct  dog  :  public  node {
	int num;
	void bark(void) {
		printf("i am num %d, wang ..\n", this->num);
	}
};

struct  lang  :  public dog  {
	void bark(void ) {
		printf(" I AM A  LANG\n");
	}
};

int  main(void)
{
	dog  wc, lf;
	node  *p;
	
	wc.num = 5;
	wc.bark();

	lf.num = 6;
	lf.bark();	

	p = &lf;
	p->bark();

	dog *p1;
	lang   xhh;

	p1 = &xhh;
	p1->bark();
	return 0;
}




