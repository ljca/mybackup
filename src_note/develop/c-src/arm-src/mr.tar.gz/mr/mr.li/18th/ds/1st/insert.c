#include <stdio.h>

struct  dog {
	int num;
	int color;	
	int sex;
	int type;

	struct dog  *next;		
	struct dog  *prev;
};


void  insert(struct dog  **h,  struct dog  demo  )
{
	struct dog  *new  = malloc(sizeof(struct dog));
	struct dog  *tmp = NULL;

	memcpy(new, &demo, sizeof(struct dog));
	new->next = NULL;

	if (*h ==  NULL) {
		*h = new;	
	} else {
		tmp =  *h;	

		while (tmp->next != NULL) {
			tmp = tmp->next;
		}	
		tmp->next = new;
	}
}

void  insert_invert(struct dog  **h,  struct dog  demo  )
{
	struct dog  *new  = malloc(sizeof(struct dog));
	struct dog  *tmp = NULL;

	memcpy(new, &demo, sizeof(struct dog));
	new->next = NULL;
	new->prev = NULL;

	if (*h ==  NULL) {
		*h = new;	
	} else {
		tmp =  *h;	

		while (tmp->next != NULL) {
			tmp = tmp->next;
		}	
		tmp->next = new;
		new->prev = tmp;
	}
}

void show_dog(struct dog *d)
{
	printf("  num: %d,  type: %d\n", d->num, d->type);
}
void show_dog_list(struct dog *h)
{
	printf("\n");	
	printf("======---------  dog list -------=========\n");
	while(h) {
		show_dog(h);	
		h = h->next;
	}
	printf("\n");
	printf("\n");
}

void show_dog_list_invert(struct dog *h)
{
	struct dog  *tail = NULL;		
	printf("\n");	
	printf("======----- invert  dog list ---=========\n");
	
	if (h == NULL) {
		return;
	}

	tail = h;
	while(tail->next != NULL) {
		tail = tail->next;
	}

	while(tail) {
		show_dog(tail);	
		tail = tail->prev;
	}
}

int main(int argc, char **argv)
{
	struct dog *h = NULL;
	struct dog  d;
	int i;
	for (i = 0; i < 4; i ++) {
		d.num = i;
		insert_invert(&h, d);
	}

	show_dog_list(h);
	show_dog_list_invert(h);
	return 0;
}
