
#include <stdio.h>

struct node {
	node *next;

	virtual  void bark(void) {
		printf(" i am a node.\n");
	}
};

struct  dog  :  public  node {
	int num;
	void bark(void) {
		printf("i am num %d, wang ..\n", this->num);
	}
};

int  main(void)
{
	dog *p;
	p = new dog;
	delete p;

	int *p1;
	p1 = new int[10];

	delete [] p1;

	p = new dog[10];
	delete [] p;
	return 0;
}




