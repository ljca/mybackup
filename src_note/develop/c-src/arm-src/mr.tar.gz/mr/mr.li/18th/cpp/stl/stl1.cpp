#include <stdio.h>
#include <memory.h>
#include <string>
#include <iostream>
#include <list>

using namespace std;

class  dog {
public:
	int num;
	void eat(void) {
		cout << " i am dog" << num << endl;
	}	
};

int  main(void)
{
	list<dog>   dlist;	
	list<dog>::iterator  obj;
	int i;	
	dog  tmp;

	for (i = 0; i < 10; i ++ ) {
		tmp.num = i;	
		dlist.push_back(tmp);
	}

	obj = dlist.begin();
	(*obj).eat();

	obj ++;
	(*obj).eat();
	return 0;
}



