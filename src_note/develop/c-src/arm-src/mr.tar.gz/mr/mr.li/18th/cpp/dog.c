#include <stdio.h>

struct dog {
	int num;
	
	void (*bark)(struct dog *);	
};

int dog_bark(struct dog  *this)
{
	printf("i am num %d, wang....\n", this->num );	
}

void init_dog(struct dog *d)
{
	d->bark = dog_bark;
}

int main(void)
{
	struct dog  wc, lf; //实例化
	init_dog(&wc);    init_dog(&lf);

	wc.num = 5;       lf.num = 6;
	wc.bark(&wc);     lf.bark(&lf);
	return 0;
}

