#include <stdio.h>
#include <memory.h>
#include <string>
#include <iostream>
#include <list>
#include <algorithm>
using namespace std;

class  dog {
public:
	int num;
	void eat(void) {
		cout << " i am dog" << num << endl;
	}	
};

class  dog_compare {
private:
	int num;
public:
	dog_compare(int num = 0) {
		this->num = num;
	}

	bool operator()(dog  &ref) const {
		if (ref.num < num) {
			return true;
		}
		return false;
	}
};

int compare(dog *a, dog *b)
{
}

int  main(void)
{
	list<dog>   dlist;	
	list<dog>::iterator  obj;
	int i;	
	dog  tmp;

	for (i = 0; i < 10; i ++ ) {
		tmp.num = i;	
		dlist.push_back(tmp);
	}

	for (obj = dlist.begin(); obj != dlist.end();  obj ++) {
		(*obj).eat();
	}

	cout << "...... begin to find .... " << endl;
	dog_compare   finder(6);
	list<dog>::iterator    ret;
	ret = find_if(dlist.begin(),  dlist.end(), finder);

	cout << " result:  dog" << (*ret).num << endl;
	ret ++;
	cout << " result:  dog" << (*ret).num << endl;
	return 0;
}



