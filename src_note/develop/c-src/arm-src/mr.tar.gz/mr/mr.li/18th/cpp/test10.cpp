#include <stdio.h>
#include <memory.h>
#include <string>
#include <iostream>

using namespace std;

template <class T1, class T2> class dog {
public:
	T1 age;
	T2 color;
};

template<class T> void myswap(T &a, T &b) 
{
	T temp;
	temp = a;
	a = b;
	b = temp;
}

int  main(void)
{
	dog<int, char> a, b;
	int c, d;

	myswap<dog<int, char> >(a, b);
	myswap<int>(c, d);
	return 0;
}


