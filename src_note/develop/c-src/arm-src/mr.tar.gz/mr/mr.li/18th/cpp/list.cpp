
#include <stdio.h>
#include "list.h"

node::node()
{
	next = NULL;
}

node::~node()
{
}

void insert(node **h, node *n)
{
	while( *h) {
		h = &((*h)->next);
	}
	*h = n;
}
void show_list(node *h)
{
	while(h) {
		h->show();
		h = h->next;
	}	
}
