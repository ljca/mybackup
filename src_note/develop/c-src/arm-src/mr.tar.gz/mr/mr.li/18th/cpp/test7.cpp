#include <stdio.h>
#include <memory.h>
#include <string>
#include <iostream>

using namespace std;

struct dog {
	int num;
	int age;

	void eat(void) {
		cout << " wang  wang ... " << endl;
	}

	dog operator+(dog &r) {
		dog ret;
		ret.num = num + r.num;
		ret.age = age + r.age;
		cout << "operator ... " << endl;
		return ret;
	}

	void operator=(dog r) {
		num = r.num;
		age = r.age;
	}	
};


int  main(void)
{
	dog a, b;
	dog c;

	c = b + a;

	return 0;
}


