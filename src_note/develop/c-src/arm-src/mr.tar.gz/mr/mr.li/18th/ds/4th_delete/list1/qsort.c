
#include <stdio.h>
#include <stdlib.h>


int comp(int *a, int *b)
{
	if (*a < *b) 
		return 1;
	return 0;
}

int main()
{
	int a[10];
	int i;

	for (i = 0; i < 10; i ++) {
		a[i]  = rand() % 555;
	}

	qsort(a, 10,  4,  comp );	

	for (i = 0; i < 10; i ++ ) {
		printf(" a[ %d] = %d\n", i, a[i]);
	}

	return 0;
}
