#include <stdio.h>
#include "list.h"

void  insert(struct node  **h,  struct node  *new  )
{
#if 0
	if (*h == NULL) {
		*h = new;
		return;
	}

	struct node *prev;
	prev = *h;
	while(prev->next) {
		prev = prev->next;
	}
	prev->next = new;
#else
//-----------------------
	while(*h) {
		h =  &((*h)->next);
	}
	*h = new;
#endif
}

void show_list(struct node *h, void (*show)(struct node *)  )
{
	while(h) {
		show_dog(h);
		h = h->next;
	}
}

struct node *search(struct node *h, int (*comp)(struct node *, struct node *), struct node *d ,
						struct node * (*copy_new)(struct node *))
{
	struct node  *new_list = NULL;
	struct node *new;
	while (h) {
		if (0 == comp(h, d)) {
			new = copy_new(h);
			insert(&new_list,  new);
		}

		h = h->next;
	}
	
	return new_list;
}


void delete(struct node **h, int (*comp)(struct node *, struct node *), struct node *d, 
				void (*object_delete)(struct node * ))
{
	struct node *tmp;
	while (*h) {
		if (0 == comp(*h, d)) {
			tmp = *h;
			*h = (*h)->next;				
			object_delete(tmp);
		}  else {
			h = &((*h)->next);
		}
	}		
}

void sort(struct node **h,  int (*comp)(struct node *, struct node *))
{
	struct node **mov;
	while(*h) {
		mov = &((*h)->next);	

		while (*mov) {	
			if (0 == comp(*h, *mov)) {
				struct node *tmp;	

				tmp = (*h)->next;
				(*h)->next = (*mov)->next;

				if (*mov == tmp) {
					(*mov)->next = *h;
					
					tmp = *h;
					*h = *mov;
					*mov = (*mov)->next;
				} else {
					(*mov)->next = tmp;

					tmp = *h;
					*h = *mov;
					*mov = tmp;
				}
			}

			mov = &((*mov)->next);
		}
	
		h = &((*h)->next);
	}
}






