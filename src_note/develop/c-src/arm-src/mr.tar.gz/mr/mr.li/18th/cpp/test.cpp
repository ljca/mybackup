
#include <stdio.h>

struct node {
	node *next;
};

struct  dog  :  public  node {
	int num;
	void bark(void) {
		printf("i am num %d, wang ..\n", this->num);
	}
};


int  main(void)
{
	dog  wc, lf;
	wc.num = 5;
	wc.bark();

	lf.bark();	
	return 0;
}
