
#include <stdio.h>
#include <memory.h>

struct node {
	node *next;

	node (void) {
		printf(" node cons\n");	
	};	
	node (int) {
		printf(" node cons\n");	
	};

	virtual ~node() {
		printf(" node disc\n");
	};		

	virtual  void bark(void) {
		printf(" i am a node.\n");
	}
};

struct  dog  :  public  node {
	int num;
	char *buf;
	void bark(void) {
		printf("i am num %d, wang ..\n", this->num);
	}
	
	dog () {
		 printf("dog cons\n");
		buf = new char[100];
		 }
	dog (int arg) {  
		num = arg; 
		printf("dog cons arg \n" ); 
	}
	dog (int arg1, int arg2) {
		num = arg1 + arg2;
	}

	dog  (dog &ref) {
		this->num = ref.num;
	//	this->buf = ref.buf;  //浅拷被
		this->buf = new char[100];
		memcpy(this->buf,  ref.buf, 100);
	}


	~dog () { printf("dog disc\n");  delete [] buf;}
};



int  main(void)
{
	dog a;
	dog b(5);
	dog c(5, 6);
	
	dog *p;
	p = new dog(5, 6);

	delete p;

	dog r = b;

	return 0;
}




