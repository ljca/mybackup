#include <stdio.h>
#include <memory.h>
#include <string>
#include <iostream>

using std::cout;
using std::endl;

namespace  bunfly {
struct node {
	node *next;

	node (void) {
		cout << "node cons" << endl;
	};	

	node (int a) {
		cout << "node arg " << a << endl;
	}

	virtual ~node() {
		printf(" node disc\n");
	};		

	virtual  void bark(void) {
		printf(" i am a node.\n");
	}
};

struct  dog  :  public  node {

	struct  tide {
		int color;
		void eat() {};
	};

	int num;
	char *buf;
	void bark(void) {
		cout << "i am num " << this->num << ", wang..." << endl;
	}
	
	dog () {
		 printf("dog cons\n");
		buf = new char[100];
		 }
	dog (int arg) {  
		num = arg; 
		buf = new char[100];
		printf("dog cons arg \n" ); 
	}
	dog (int arg1, int arg2) : node(arg2) {
		buf = new char[100];
		num = arg1 + arg2;
	}

	dog  (dog &ref) {
		this->num = ref.num;
	//	this->buf = ref.buf;  //浅拷被
		this->buf = new char[100];
		memcpy(this->buf,  ref.buf, 100);
	}


	~dog () { printf("dog disc\n");  delete [] buf;}

	static void eat(void) {
		printf(" dog eat...\n");
	}
};

struct string {
	char buf[50];
};
};

//using namespace bunfly;
//using namespace std;
using bunfly::dog;
using std::string;

int  long_add(int a, int b, int c , int d = 0, int e = 1, int f = 0)
{
	return a + b + c + d + e + f;
}

int  main(void)
{
	long_add(45, 6, 7);

	dog wc(5, 6);
	return 0;
}


