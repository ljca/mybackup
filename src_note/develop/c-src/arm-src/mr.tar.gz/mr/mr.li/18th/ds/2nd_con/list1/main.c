#include <stdio.h>
#include "list.h"

struct dog {
	int num;
	int type;
	int color;
	struct node no;
};

void show_dog(struct node *no)
{
	struct  dog *d;
	struct  dog *tmp = 0;
	int offset;

	offset = (int)(&tmp->no);
	d =  (int)no  - offset;	
	printf("  num: %d,  type: %d\n", d->num, d->type);
}

int main(int argc, char **argv)
{
	struct node *h = NULL;
	struct dog  *d = NULL;
	int i;
	for (i = 0; i < 4; i ++) {
		d = malloc(sizeof(struct dog));
		d->num = i;
		insert(&h, &d->no);
	}

	show_list(h, show_dog);
	return 0;
}
