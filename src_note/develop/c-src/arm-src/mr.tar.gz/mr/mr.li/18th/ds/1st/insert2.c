#include <stdio.h>

struct  dog {
	int num;
	int color;	
	int type;

	struct dog  *next;		
	struct dog  *prev;
};

void  insert(struct dog  **h,  struct dog  demo  )
{
	struct dog  *new  = malloc(sizeof(struct dog));
	struct dog  *tmp = NULL;

	memcpy(new, &demo, sizeof(struct dog));
	new->next = NULL;

	while(*h != NULL) {
		h = &(*h)->next;
	}

	*h = new;
}

void  insert_invert(struct dog  **h,  struct dog  demo  )
{
	struct dog  *new  = malloc(sizeof(struct dog));
	struct dog  *tmp = NULL;

	memcpy(new, &demo, sizeof(struct dog));
	new->next = NULL;
	new->prev = NULL;

	if (*h ==  NULL) {
		*h = new;	
	} else {
		tmp =  *h;	

		while (tmp->next != NULL) {
			tmp = tmp->next;
		}	
		tmp->next = new;
		new->prev = tmp;
	}
}

void show_dog(struct dog *d)
{
	printf("  num: %d,  type: %d\n", d->num, d->type);
}
void show_dog_list(struct dog *h)
{
	printf("\n");	
	printf("======---------  dog list -------=========\n");
	while(h) {
		show_dog(h);	
		h = h->next;
	}
	printf("\n");
	printf("\n");
}

void show_dog_list_invert(struct dog *h)
{
	struct dog  *tail = NULL;		
	printf("\n");	
	printf("======----- invert  dog list ---=========\n");
	
	if (h == NULL) {
		return;
	}

	tail = h;
	while(tail->next != NULL) {
		tail = tail->next;
	}

	while(tail) {
		show_dog(tail);	
		tail = tail->prev;
	}
}

void delete(struct dog  **h,  int num)
{
	struct  dog   *cur = NULL;
	printf("---------------- delete ----------------\n");
	if (*h == NULL) {
		return;
	}	

	if ((*h)->num == num) {
		*h =  (*h)->next;	
		if (*h) {
			(*h)->prev = NULL;
		}
		return;
	}
	
	cur = (*h)->next;
	while  (cur) {
		if (cur->num == num) {
			cur->prev->next = cur->next;
			if (cur->next) {
				cur->next->prev = cur->prev;
			}
		}	
		cur = cur->next;
	}
}

int main(int argc, char **argv)
{
	struct dog *head = NULL;
	struct dog  d;
	int i;
	for (i = 0; i < 4; i ++) {
		d.num = i;
		insert_invert(&head, d);
	}

	show_dog_list(head);

	delete(&head, 2);

	show_dog_list(head);
	show_dog_list_invert(head);
	return 0;
}
