#include <stdio.h>
#include "list.h"

struct dog {
	int num;
	int type;
	int color;
	struct node no;
};

#define container_of(ptr, type, member)    ((int)ptr  - (int)(&(((type *)0)->member)))
void show_dog(struct node *n)
{
	struct dog *d;

	d  = container_of(n, struct dog, no);

	printf("  num: %d,  type: %d\n", d->num, d->type);
}

int comp_num(struct node *cur, struct node *arg)
{
	struct dog  *c, *a;
	c = container_of(cur, struct dog, no);
	a = container_of(arg, struct dog, no);
	if (c->num < a->num) 
		return 0;
	return 1;
}

int comp_color(struct node *cur, struct node *arg)
{
	struct dog  *c, *a;
	c = container_of(cur, struct dog, no);
	a = container_of(arg, struct dog, no);
	if (c->color == a->color) 
		return 0;
	return 1;
}

struct node *dog_newcopy(struct node *n)
{
	struct dog   *a;
	struct dog   *new;
	a = container_of(n, struct dog, no);
	new = malloc(sizeof(struct dog));
	memcpy(new, a, sizeof(struct dog));
	new->no.next = NULL;
	return &new->no;
}

void  dog_delete(struct node *n)
{
	struct dog   *d;
	d = container_of(n, struct dog, no);
	free(d);
}

int comp_rising(struct node *a, struct node *b)
{
	struct dog   *doga, *dogb;
	doga = container_of(a, struct dog, no);
	dogb = container_of(b, struct dog, no);

	if (doga->num  > dogb->num)
		return 0;
	return 1;
}

int main(int argc, char **argv)
{
	struct node *h = NULL;
	struct dog  *d = NULL;
	int i;
	
	for (i = 0; i < 11; i ++) {
		d = malloc(sizeof(struct dog)); 	
		d->num = rand() % 555;
		d->no.next = NULL;
		if ((i %  5) == 0) {
			d->color = 0xffffff;
		}
		insert(&h, &d->no);
	}
	show_list(h, show_dog );

	printf("...........  sort ......\n");
	sort(&h, comp_rising);
	show_list(h, show_dog);

	struct node *find_list = NULL;
	struct dog  arg;

	printf("........search  less than num 5.....\n");
	arg.num = 5;
	find_list = search(h, comp_num, &arg.no, dog_newcopy);
	show_list(find_list, show_dog);

	printf(" ......   search black dog .....\n");
	arg.color = 0xffffff;
	find_list = search(h, comp_color, &arg.no, dog_newcopy);
	show_list(find_list, show_dog);

	printf("........delete  less than num 5.....\n");
	arg.num = 5;
	delete(&h, comp_num, &arg.no, dog_delete);
	show_list(h, show_dog);
	
	return 0;
}


