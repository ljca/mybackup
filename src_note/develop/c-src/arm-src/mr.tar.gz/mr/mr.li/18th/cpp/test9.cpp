#include <stdio.h>
#include <memory.h>
#include <string>
#include <iostream>

using namespace std;
class  women {
private:
	int num;
	int age;
	int bra_size;

	friend  int main(void);
protected:
	void eat(void) {
		cout << " wang  wang ... " << endl;
	}

public:
	women operator+(women &r) {
		women ret;
		ret.num = num + r.num;
		ret.age = age + r.age;
		cout << "operator ... " << endl;
		return ret;
	}

	friend struct dog;
	void operator=(women r) {
		num = r.num;
		age = r.age;
	}	
};

class dog {
	void  see() {
		women  owner;
		int size;
		size = owner.bra_size;
	}
};

int  main(void)
{
	women a, b;
	women c;
	int size;

	c = b + a;

//	a.num = 5;  //error  
//	a.eat();   //error

	size = a.bra_size;
	return 0;
}


