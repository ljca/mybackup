
#include <stdio.h>
#include <stdlib.h>
#include "list.h"

struct dog : public node {
	int num;  int type; int color	;
	
	void show() {
		printf("num: %d, \n", num);	
	}
};


int main(int argc, char **argv)
{
	node  *h = NULL;
	dog  *d = NULL;
	int i;

	for (i = 0; i < 11; i ++) {
		d = new dog;
		d->num = rand() % 555;
		if ((i % 5) == 0) {
			d->color = 0xffffff;
		}	
		insert(&h,  d);
	}
	show_list(h);
	return 0;
}





