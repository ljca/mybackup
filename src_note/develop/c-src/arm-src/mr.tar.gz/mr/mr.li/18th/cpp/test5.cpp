#include <stdio.h>
#include <memory.h>
#include <string>
#include <iostream>

using std::cout;
using std::endl;
namespace  bunfly {
struct node {
	node *next;

	node (void) {
		cout << "node cons" << endl;
	};	
	node (int) {
		cout << "node cons" << endl;
	};

	virtual ~node() {
		printf(" node disc\n");
	};		

	virtual  void bark(void) {
		printf(" i am a node.\n");
	}
};

struct  dog  :  public  node {

	struct  tide {
		int color;
		void eat() {};
	};

	int num;
	char *buf;
	void bark(void) {
		cout << "i am num " << this->num << ", wang..." << endl;
	}
	
	dog () {
		 printf("dog cons\n");
		buf = new char[100];
		 }
	dog (int arg) {  
		num = arg; 
		buf = new char[100];
		printf("dog cons arg \n" ); 
	}
	dog (int arg1, int arg2) {
		buf = new char[100];
		num = arg1 + arg2;
	}

	dog  (dog &ref) {
		this->num = ref.num;
	//	this->buf = ref.buf;  //浅拷被
		this->buf = new char[100];
		memcpy(this->buf,  ref.buf, 100);
	}


	~dog () { printf("dog disc\n");  delete [] buf;}

	static void eat(void) {
		printf(" dog eat...\n");
	}
};

struct string {
	char buf[50];
};
};

//using namespace bunfly;
//using namespace std;
using bunfly::dog;
using std::string;

int  main(void)
{
	dog::tide  xx;
	dog::eat();

	dog a;
	dog b(5);
	dog c(5, 6);
	
	dog *p;
	p = new dog(5, 6);

	delete p;

	dog r = b;

	::memcpy((void *)5, (void *)6, 1);
	string  str;
	return 0;
}


