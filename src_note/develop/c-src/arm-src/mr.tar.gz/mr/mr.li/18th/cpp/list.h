#pragma once


struct node {
	node *next;

	node();
	~node();
	virtual void show() = 0;
};

void insert(node **h, node *n);
void show_list(node *h);
