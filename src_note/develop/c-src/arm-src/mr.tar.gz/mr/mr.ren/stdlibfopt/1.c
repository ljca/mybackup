#include <stdio.h>
#include <string.h>

int main()
{
	FILE *fp = fopen("test", "a+");
	if(NULL == fp) {
		perror("open test error\n");
		return -1;
	}
	char *s = "haha";
	fwrite(s, strlen(s), 1, fp);
	fseek(fp, 0, SEEK_SET);
	char buf[100] = {0};
	int ret = fread(buf, 10, 10, fp);	
	printf("%s\n", buf);
	
	fclose(fp);
	return 0;
}
