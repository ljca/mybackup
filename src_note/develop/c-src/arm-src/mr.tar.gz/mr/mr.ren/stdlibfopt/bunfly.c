#include <stdio.h>
#include <string.h>

int main()
{
	//stdin stdout strerr
	char buf[100] = {0};
	fread(buf, 5, 1, stdin);
	fwrite(buf, strlen(buf), 1, stdout);

	printf("stdin %d\n", stdin->_fileno);
	printf("stdout %d\n", stdout->_fileno);
	printf("stderr %d\n", stderr->_fileno);

	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
