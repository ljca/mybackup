#include <stdio.h>
#include <stdlib.h>

int bss;
int g = 10;
extern int a;

int main()
{
	printf("a is %d\n", a);
	static int st = 20;
	hello();
	int *h = malloc(20);
	char *ro = "bunfly";

	printf("&h is stack %p\n", &h);
	printf("&ro is stack %p\n", &ro);
	printf("h is heap %p\n", h);
	printf("bss %p\n", &bss);
	printf("global %p\n", &g);
	printf("st static %p\n", &st);
	printf("readonly is %p\n", ro);
	printf("main code %p\n", main);
	printf("hello code %p\n", hello);

	return 0;
}
