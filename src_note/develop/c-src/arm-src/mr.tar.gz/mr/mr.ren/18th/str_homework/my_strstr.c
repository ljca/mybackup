#include <stdio.h>

char *my_strstr(char *s, char *d)
{
	int index = 0;
	char *t = d;
	while(*s && *d) {
		if(*s == *d) {
			s++;
			d++;
			index++;
		}else{
			s = s - index + 1;
			d = t;
			index = 0;
		}
	}	
	if('\0' == *s)
		return NULL;
	else
		return s - index;

}

int main()
{
	char *s = "hello fbunssay haaadasaa";
	char *d = "af";
	char *p = my_strstr(s, d);
	printf("%s\n", p);
	return 0;
}




