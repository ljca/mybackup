#include <stdio.h>

enum num {a, b, c = 90, d};

int main()
{
	printf("a is %d\n", a);
	printf("b is %d\n", b);
	printf("c is %d\n", c);
	printf("d is %d\n", d);
	return 0;
}





