#include <stdio.h>

int main()
{
	int x = 5;
	int y = 2;
	printf("x & y %d\n", x & y);
	printf("x | y %d\n", x | y);
	printf("x ^ y %d\n", x ^ y);
	printf("~x %d\n", ~x);
	printf("~x %x\n", ~x);
	int a = 10;
	printf("a << 2 %d\n", a << 2);
	printf("a >> 2 %d\n", a >> 2);
	return 0;
}
