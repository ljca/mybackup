#include <stdio.h>

typedef struct person{
	int a;
	int n;
}p_t;

int add(int a, int b)
{
	return a + b;
}

int main()
{
	p_t p;
	p.a = 10;
	p.n = 20;
	printf("p.a %d\n", p.a);
	int sum = add(p.a, p.n);
	printf("sum is %d\n", sum);
	int (*fp)(int, int) = add;
	sum = fp(11, 22);
	printf("sum is %d\n", sum);
	typedef int (*FP)(int, int);
	FP fp1 = add; //FP fp1 = fp;
	sum = fp1(20, 30);
	printf("sum is %d\n", sum);
	return 0;
}





