#include <stdio.h>
#include <string.h>


int main()
{
	char *s = "helo bunflly";

	char *p = strstr(s, "ll");
	printf("%s\n", p);
	char *s1 = "hellollll";
	char *s2 = "hello";
	int i = strcmp(s1, s2);
	i = strncmp(s1, s2, 5);
	printf("i is %d\n", i);

	return 0;
}





