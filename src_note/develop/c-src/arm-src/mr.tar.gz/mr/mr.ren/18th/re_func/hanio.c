#include <stdio.h>

void move(int num, char a, char b, char c)
{
	if(1 == num) {
		printf("%d move %c to %c\n", num, a, c);
		return;
	}
	move(num-1, a, c, b);
	printf("%d move %c to %c\n", num, a, c);
	move(num-1, b, a, c);
}

int main()
{
	int n = 3;
	char a1 = 'A';
	char b1 = 'B';
	char c1 = 'C';
	move(n, a1, b1, c1);
	return 0;
}
