#ifndef __LINK_H
#define __LINK_H

#include <stdio.h>
#include <stdlib.h>

#define MALLOC(type) (type *)malloc(sizeof(type))

struct dog{
	int num;
	struct dog *next;
};

struct dog *insert_head(struct dog *head, int n);
struct dog *insert_tail(struct dog *head, int n);
void show(struct dog *head);
void find(struct dog *h, int n);
struct dog *convert(struct dog *h);
struct dog *sort(struct dog *h);

#endif
