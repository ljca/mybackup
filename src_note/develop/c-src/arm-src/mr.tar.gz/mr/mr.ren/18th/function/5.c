#include <stdio.h>

//void init(int b[5], int a[5])
void init(int *b, int *a)
{
	printf("sizeof(a) %d\n", sizeof(a));
	int i = 0;
	for(i = 0; i < 5; i++) {
		b[i] = *(a + i);
	}
}
int *init_1(int *b, int *a)
{
	printf("sizeof(a) %d\n", sizeof(a));
	int i = 0;
	for(i = 0; i < 5; i++) {
		b[i] = *(a + i);
	}
	return b;
}	

int main(int argc, char *argv[])
{
	int arr[5] = {1, 2, 3, 4, 5};
	int brr[5] = {0};
	//init(brr, arr);
	int i = 0;
	int *p = init_1(brr, arr);
	printf("brr %p\n", brr);
	printf("p %p\n", p);
	for(i = 0; i < 5; i++) {
		printf("p[%d] %d\n", i, p[i]);
	}
	return 0;
}

