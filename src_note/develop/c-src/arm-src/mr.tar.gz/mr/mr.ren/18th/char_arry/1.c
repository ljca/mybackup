#include <stdio.h>
#include <string.h>

int main()
{
	char arr[5] = {'a', 'b', 'c', '1', '@'};
	char str[20] = "hello world";
	printf("%s\n", str);
	printf("strlen(str) %d\n", strlen(str));
	printf("sizeof(\"hello world\") %d\n", sizeof("hello world"));
	printf("sizeof(str) %d\n", sizeof(str));
	int len = 0;
	char *p = str;
	while(*(p++)) {
		//p++;
		len++;
	}
	printf("len is %d\n", len);

	return 0;
}
