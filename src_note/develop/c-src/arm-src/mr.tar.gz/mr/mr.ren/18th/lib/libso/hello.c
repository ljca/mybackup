#include "hello.h"

void hello()
{
	printf("hello bunfly\n");
}
