#include <stdio.h>

int main()
{
	char i = 'a';
//	void v = 10; //error
	void *p = &i;
	char *p1 = &i;
	printf("sizeof(p) %d\n", sizeof(p));
	printf("*p1 %d\n", *p1);
	printf("sizeof(*p1) %d\n", sizeof(*p1));
	//printf("*p %d\n", *p); error
	printf("*((char *)p) %d\n", *((char *)p)); 
	

	return 0;
}
