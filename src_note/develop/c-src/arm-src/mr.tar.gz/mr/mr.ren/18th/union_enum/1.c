#include <stdio.h>

struct dog{
	int a;
	char b[10];
};

union u_dog{
	int a;
	char b[10];
};

int main()
{
	struct dog d;
	union u_dog ud;
	printf("sizeof(d) %d\n", sizeof(d));
	printf("sizeof(ud) %d\n", sizeof(ud));
	return 0;
}





