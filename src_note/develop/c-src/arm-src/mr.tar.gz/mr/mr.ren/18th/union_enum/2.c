#include <stdio.h>

struct dog{
	int a;
	char b;
};

union u_dog{
	int a;
	char b;
};

int main()
{
	struct dog d;
	union u_dog ud;
	printf("sizeof(d) %d\n", sizeof(d));
	printf("sizeof(ud) %d\n", sizeof(ud));
	d.a = 10;
	d.b = 'a';
	printf("d.a is %d\n", d.a);
	printf("d.b is %c\n", d.b);
	ud.a = 10;
	ud.b = 'a';
	printf("ud.a is %d\n", ud.a);
	printf("ud.b is %c\n", ud.b);

	return 0;
}





