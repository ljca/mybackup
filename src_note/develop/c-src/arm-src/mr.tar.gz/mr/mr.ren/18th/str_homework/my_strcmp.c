#include <stdio.h>

int my_strcmp(char *s1, char *s2)
{
	while(*s1 && *s2) { //while(*s1 || *s2)
		if(*s1 > *s2) {
			return 1;
		}else if(*s1 < *s2) {
			return -1;
		}
		s1++;
		s2++;
	}
	if(*s1) {
		return 1;
	}
	if(*s2)
		return -1;

	return 0;
}

int main()
{
	int i = 0;
	char *s1 = "helloll";
	char *s2 = "hello";

	i = my_strcmp(s1, s2);
	printf("%d\n", i);

	return 0;
}

