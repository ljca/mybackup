#include <stdio.h>

#define PCHAR char *
#define BUFSIZE 1024
#define MAX(a, b)  (a) > (b) ? (a) : (b)
#define SUM(a, b) ((a) + (b))

int sum(int a, int b)
{
	printf("sum is %d\n", a + b);
	return a + b;
}

int main()
{	
	int arr[BUFSIZE];
	printf("max is %d\n", MAX(10, 5));
	printf("SUM is %d\n", SUM(10, 10));
	sum(20, 10);
	printf("SUM is %d\n", SUM(10, 20)*SUM(10, 20));
	int ret = sum(10, 20)*sum(10, 20);
	printf("ret is %d\n", ret);

	return 0;
}
