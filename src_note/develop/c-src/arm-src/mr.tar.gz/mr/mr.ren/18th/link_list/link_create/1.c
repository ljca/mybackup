#include <stdio.h>

struct dog{
	int num;
	char *name;
	struct dog *next;
};

int main()
{
	struct dog d[3];
	d[0].num = 1;
	d[1].num = 2;
	d[2].num = 3;
	d[0].next = &d[1];
	d[1].next = d + 2;
	d[2].next = NULL;
	
	printf("d[0].num %d\n", d[0].num);
	printf("d[1].num %d\n", d[0].next->num);
	printf("d[2].num %d\n", d[0].next->next->num);

	return 0;
}
