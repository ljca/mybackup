#include <stdio.h>
#include <string.h>

int main()
{

	char *s = "hello bunfly";
	int len = strlen(s);
	printf("len %d\n", len);
	char buf[20] = {0};
	printf("buf is %p\n", buf);
	char *p = buf;
	p = strcpy(p, s);
	printf("buf is %s\n", buf);
	printf("p save address is %p\n", p);
	printf("p is %s\n", p);
	return 0;
}


