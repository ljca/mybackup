#include <stdio.h>

enum stat {ONLINE = 1, OFFLINE, MSG, FILES}on = ONLINE,off,msg,file;

void hello()
{
	printf("hahaha wo lai le \n");
}

int main()
{
	int i = on;
	switch(i) {
		case 1:
			printf("ONLINE\n");
			hello();
			break;
		case 2:
			printf("OFFLINE\n");
			break;
		case 3:
			printf("MSG\n");
			break;
		case 4:
			printf("FILES\n");
			break;
		default:
			printf("error information\n");
	}

	return 0;
}





