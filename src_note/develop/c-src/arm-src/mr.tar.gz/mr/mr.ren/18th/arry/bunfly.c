#include <stdio.h>

int main()
{
	int month[12] = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	int days = 0;
	int m = 1;
	int d = 3;

	int i = 0;
	for(i = 0; i < m - 1; i++) {
		days += month[i];
	}
	days = days + d;
	printf("days is %d\n", days);
	if(days % 5 < 4)
		printf("dy\n");
	else
		printf("sw\n");


	return 0;
}


