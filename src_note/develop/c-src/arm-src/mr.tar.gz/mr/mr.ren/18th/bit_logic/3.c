#include <stdio.h>

int main()
{
	int x = 0xbf83f4;
	//1011 1111 1000 0011 1111 0100
	//5-13位取反，其余保持不变
	//1011 1111 1001 1100 0000 0100
	//bf9c04
	printf("%x\n", x ^ 0x1ff0);

	//取出5-20位
	int ret = (x & 0xffff0) >> 4;
	printf("%x\n", ret);
	
	//取出第一个字节的低5位，第二个字节的低6位，第三个字节的低5位组成一个新的2字节数
	//0001 1111 0000 0011 0001 0100
	ret = x & 0x1f;
	ret = ret | ((x & 0x3f00) >> 3);
	ret |= (x & 0x1f0000) >> 5;

	printf("ret %x\n", ret);
	
	return 0;
}
