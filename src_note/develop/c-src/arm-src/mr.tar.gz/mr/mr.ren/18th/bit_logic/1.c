#include <stdio.h>

int main()
{
	int x = 5;
	int y = 0;
	printf("x && y %d\n", x && y);
	printf("x || y %d\n", x || y);
	printf("!x %d\n", !x);
	return 0;
}
