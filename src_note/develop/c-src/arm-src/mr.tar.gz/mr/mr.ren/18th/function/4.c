#include <stdio.h>

void swap(int *a, int *b)
{
	int tmp = 0;
	tmp = *a;
	*a = *b;
	*b = tmp;
	printf("*a = %d, *b = %d\n", *a, *b);
}

int main(int argc, char *argv[])
{
	int x = 10;
	int y = 20;
	swap(&x, &y);
	printf("x = %d, y = %d\n", x, y);
	return 0;
}

