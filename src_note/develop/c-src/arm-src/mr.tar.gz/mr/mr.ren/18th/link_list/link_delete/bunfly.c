#include <stdio.h>
#include <stdlib.h>

#define MALLOC(type) (type *)malloc(sizeof(type))

struct dog{
	int num;
	struct dog *next;
};

struct dog *insert_head(struct dog *head, int n)
{
	struct dog *tmp = MALLOC(struct dog);
	tmp->num = n;
	tmp->next = head;

	return tmp;
}

struct dog *insert_tail(struct dog *head, int n)
{
	struct dog *h = head;
	struct dog *tail = head;
	struct dog *tmp = MALLOC(struct dog);
	tmp->num = n;
	tmp->next = NULL;
	if(NULL == h) {
		head = tmp;
	}else {	
		while(h->next) {
			h = h->next;
		}
		tail = h;
		tail->next = tmp;
	}
	return head;
}

void show(struct dog *head)
{
	printf("--------start show--------\n");
	while(head) {
		printf("num is %d\n", head->num);
		head = head->next;
	}
	printf("--------show over--------\n");
}

struct dog *find_create(struct dog *h, int n)
{
	printf("-------f_c start------\n");
	int i = 0;
	struct dog *new = NULL;
	struct dog *tmp = NULL;
	while(h) {
		i++;
		if(n == h->num) {
			printf("find num %d on %d time\n", n, i);
			tmp = MALLOC(struct dog);
			tmp->num = n;
			tmp->next = new;
			new = tmp;
		}
		h = h->next;
	}	
	printf("-------f_c over------\n");
	return  new;
}

struct dog *delete(struct dog *h, int n)
{
	struct dog *tmp = h;
	struct dog *find = h;

	while(tmp->next) {
		if(n == tmp->num) {
			find = tmp;
			h = h->next;
			tmp = h;
			free(find);
		}else if(n == tmp->next->num) {
			find = tmp->next;
			tmp->next = find->next;
			free(find);
		}else
			tmp = tmp->next;
	}

	return h;
}

void find(struct dog *h, int n);

int main()
{
	struct dog *h = NULL;
	h = insert_tail(h, 10);
	h = insert_tail(h, 10);
	h = insert_head(h, 30);
	h = insert_tail(h, 40);
	h = insert_tail(h, 10);
	h = insert_head(h, 10);
	h = insert_head(h, 10);

	show(h);
	h = delete(h, 10);
	show(h);
	free(h);	

	return 0;
}


void find(struct dog *h, int n)
{
	printf("-------find start------\n");
	int i = 0;
	int flag = 0;
	while(h) {
		i++;
		if(n == h->num) {
			flag = 1;
			printf("find num %d on %d time\n", n, i);
		}
		h = h->next;
	}	
	if(0 == flag) {
		printf("no this node\n");
	}

	printf("-------find over------\n");
}




