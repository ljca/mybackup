#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct dog{
	char b;
	int a;
	char c[10];
};


int main()
{
	struct dog d;
	printf("sizeof(struct dog) %d\n", sizeof(d));
	int i = 0;
	char c = 'a';
	int a = 10;
	return 0;
}




