#include "link.h"


struct dog *sort(struct dog *h)
{
	printf("---------sort-------\n");
	struct dog *min = h;
	struct dog *min_pre = NULL;
	struct dog *tmp = h;
	struct dog *new = NULL;
	struct dog *tail = NULL;
	
	while(h) {
		tmp = h;
		min = h;
	//step1 find min
		while(tmp->next) {
			if(min->num > tmp->next->num) {
				min = tmp->next;
				min_pre = tmp;
			}
			tmp = tmp->next;
		}
	//	printf("min->num is %d\n", min->num);
	//cut min
		if(min == h) {
			h = h->next;		
		}else {
			min_pre->next = min->next;		
		}		
	//create
#if 0 //insert head
		min->next = new;
		new = min;
#else //intsert tail
		if(NULL == tail) {
			tail = min;
			new = min;
		}else {
			tail->next = min;
			tail = min;
		}		

#endif
	}
	return new;

	printf("---------sort over-------\n");

}

