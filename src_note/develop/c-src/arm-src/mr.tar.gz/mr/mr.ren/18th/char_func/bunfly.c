#include <stdio.h>
#include <string.h>


int main()
{
	char s[100] = "aaa bbb, ccc@ ddd,eee";
	char *d = " @,";
#if 1
	char *p = strtok(s, d);
	printf("%s\n", p);
	while(p = strtok(NULL, d)) {
	//	p = strtok(NULL, d);
	//	if(NULL == p)
	//		break;
		printf("%s\n", p);
	}	
#else
	char *p = strtok(s, d);
	printf("%s\n", p);
	p = strtok(NULL, d);
	printf("%s\n", p);
	p = strtok(NULL, d);
	printf("%s\n", p);
	p = strtok(NULL, d);
	printf("%s\n", p);

#endif
	return 0;
}





