#include <stdio.h>

int main()
{
	int i = 10;
	while(1) {
		while(i--) {
			if(i == 5)
				//break;
				//continue;
				return 0;
			printf("i is %d\n", i);
		}	
	}
	return 0;
}




