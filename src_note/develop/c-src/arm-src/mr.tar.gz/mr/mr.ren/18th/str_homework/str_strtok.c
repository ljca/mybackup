#include <stdio.h>
#include <string.h>

int main()
{
	char ip[20]	= "192 168, 1 20";
	char *s = ip;
	char *r = ip;
	char *t = ip;

/*	r = strstr(s, ".");
	printf("%s\n", r); //.168.1.20
	t = strtok(s, ".");
	printf("%s\n", t);//192
	s = r + 1;
	r = strstr(s, ".");
	printf("%s\n", r); //.1.20
	t = strtok(s, ".");
	printf("%s\n", t); //168
	s = r + 1;*/
	while(r) {
		r = strstr(s, " ");
		t = strtok(s, " ");
		printf("%s\n", t);
		s = r + 1;	
	}

	return 0;
}

