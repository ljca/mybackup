#include <stdio.h>

int my_htonl(int);

int main()
{
	unsigned long i = 0xf1223344;
	printf("my_htonl(i) = %x\n", my_htonl(i));

	return 0;
}

int my_htonl(int a)
{
	unsigned int ret = 0;
	ret |= (a & 0xff000000) >> 24;
	ret |= (a & 0xff0000) >> 8;
	ret |= (a & 0xff00) << 8;
	ret |= (a & 0xff) << 24;
	return ret;
}


