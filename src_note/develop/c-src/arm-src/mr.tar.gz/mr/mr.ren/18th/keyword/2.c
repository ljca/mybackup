#include <stdio.h>

int main()
{
	typedef int unit_32;
	typedef short unit_16;
	typedef char unit_8;
	typedef unsigned long _size_t;
	unit_32 i = 0x11223344;
	printf("%x\n", i);
	_size_t a = 0xaabbccdd;
	printf("%x\n", a);
	unit_8 c = 'a';
	typedef char * p_char;
#define PCHAR char *
	p_char pa, pb;
	pa = &c;
	pb = &c;
	char *pa1, pb1;
	pa1 = &c;
//	pb1 = &c; pb1是char型的
	PCHAR pa2, pb2;
	pa2 = &c;
	pb2 = &c; //pb2是char型的
	
	return 0;
}





