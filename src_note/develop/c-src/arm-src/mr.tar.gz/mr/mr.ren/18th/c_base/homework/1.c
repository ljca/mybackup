#include <stdio.h>

int main()
{
	int a = 79;
	int tmp[100] = {0}; 
	int i = 1;
	while(a > 1) {
		tmp[i] = a % 2;
		i++;
		//printf("%d\n", a % 2);
		a = a / 2; // a /= 2;
	}
	tmp[i] = a;
	//printf("%d\n", a);
	while(i) {
		printf("%d\n", tmp[i]);
		i--;
	}

	return 0;
}
