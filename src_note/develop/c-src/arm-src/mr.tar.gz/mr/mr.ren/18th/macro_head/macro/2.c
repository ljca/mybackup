#include <stdio.h>
#include <stdlib.h>

#define MALLOC(type, n) (type *)malloc(sizeof(type)*n)
#define NUM(a) sizeof(a)/sizeof(*a)
int Num(int arr[]) //int *arr
{
	printf("-----> %d\n", sizeof(arr) / sizeof(*arr));
	return sizeof(arr) / sizeof(*arr);
}

int main()
{
	int *p = MALLOC(int, 5);
	p[0] = 10;
	p[4] = 30;
	int arr[] = {1, 2, 3, 4, 5};
	//int num = sizeof(arr)/sizeof(*arr);
	int num = NUM(arr);
	printf("num is %d\n", num);
	int num1 = Num(arr);
	printf("num1 is %d\n", num1);
	return 0;
}
