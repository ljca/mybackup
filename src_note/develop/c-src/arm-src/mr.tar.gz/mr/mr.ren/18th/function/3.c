#include <stdio.h>

void swap(int a, int b)
{
	int tmp = 0;
	tmp = a;
	a = b;
	b = tmp;
	printf("a = %d, b = %d\n", a, b);
}

int main(int argc, char *argv[])
{
	int a = 10;
	int b = 20;
	swap(a, b);
	printf("a = %d, b = %d\n", a, b);
	return 0;
}

