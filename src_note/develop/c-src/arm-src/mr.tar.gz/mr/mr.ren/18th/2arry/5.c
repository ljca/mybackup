#include <stdio.h>

int main()
{
	int arr[3][2] = {{1, 3}, {5, 2}, {4, 6}}; 
	//int arr[3][2] = {1, 2, 3, 4, 5, 6};
	int (*p)[2]; // 数组指针
	p = arr;
	printf("sizeof(p) %d\n", sizeof(p));
	printf("sizeof(arr) %d\n", sizeof(arr));
	int i = 0, j = 0;
	for(i = 0; i < 6; i++) {
		printf("%p\t", *p + i);
		printf("%d\n", *(*p + i));
	}
	int *p1 = &i;
	int *p2 = &j;
	int *brr[3] = {p1, p2};  //指针数组
	printf("sizeof(brr) %d\n", sizeof(brr));
	printf("brr[0] %p\n", brr[0]);
	printf("brr[1] %p\n", brr[1]);
	printf("*brr[0] %d\n", **brr);
	printf("*brr[1] %d\n", **(brr + 1));
	int **pt = brr;

	return 0;
}




