#include <stdio.h> //头文件
#include <stdlib.h>

int main()
{
	int *p = malloc(sizeof(int)*5);
	printf("p %p\n", p);
	printf("&p %p\n", &p);
	free(p); //内存泄漏
	p = NULL; //野指针
	return 0;
}









