#include <stdio.h>


int main()
{
	const int i = 10;
//	i = 20; error
	printf("%d\n", i);
	char s[100] = "hello";
	char s1[100] = "bunfly";
	const char *p = s;
//	*p = 'H';  // error
	p = s1;
	char const *p1 = s;
//	*p1 = 'H'; // error
	p1 = s1;
	char *const p2 = s;
	*p2 = 'H';
//	p2 = s1;  //error

	return 0;
}





