/*
 *function:  
 *author:
 *date:
 *
 */

#include <stdio.h> //头文件

int main()
{
#if 0
	int i = 10;
	int *p;
	p = &i; // int *p = &i;
	printf("&i is %p\n", &i);
	printf("&p is %p\n", &p);
	printf("p save address is %p\n", p);
	printf("*p is %d\n", *p);
	//p = 0x0;
	//printf("*p is %d\n", *p); error
	printf("sizeof(p) %d\n", sizeof(p));	
	char *pc;
	printf("sizeof(pc) %d\n", sizeof(pc));	
	int **p1 = &p;
	printf("p1 save address is %p\n", p1);
	printf("*p1 is %p\n", *p1);
	printf("**p1 is %d\n", **p1);
	int ****************pn;
	int *****************pn1 = &pn;
	i = (int)p;
	printf("i %x\n", i);
	p = &p1;

#else 
	int arr[5] = {1, 2, 3, 4, 5}; 
	int *p = arr;
	int i = 0;
	for(i = 0; i < 5; i++) {
		printf("%d\n", *(p + i));
	}

#endif
	return 0;
}









