#include <stdio.h>

int (*convert(int (*a)[3], int (*b)[2]))[2];
void show(int (*b)[2]);

int main()
{
	int arr[2][3] = {1, 3, 5, 2, 4, 6};
	int brr[3][2] = {0};
	printf("brr %p\n", brr);
	int (*p)[2] = convert(arr, brr);
	printf("p %p\n", p);
	show(p);

	return 0;
}

void show(int (*b)[2])
{
	int i = 0;
	for(i = 0; i < 6; i++) {
		printf("%d\n", *(*b + i));
	}
}

//int (*)[2] convert(int (*a)[3], int (*b)[2])
int (*convert(int (*a)[3], int (*b)[2]))[2]
{
	int i = 0, j = 0;
	for(i = 0; i < 3; i++) 
	{
		for(j = 0; j < 2; j++) {
			b[i][j] = *(*(a + j) + i);
		}	
	}

	printf("b %p\n", b);

	return b;
}


