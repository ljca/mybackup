#include <stdio.h>

int main()
{
	unsigned long i = 0x11223344;
	printf("i is %x\n", i);
	printf("htonl(i) is %x\n", htonl(i));
	return 0;
}
