#include <stdio.h>

int main()
{
	int arr[3][2] = {{1, 3}, {5, 2}, {4, 6}}; 
	//int arr[3][2] = {1, 2, 3, 4, 5, 6};
	int (*p)[2]; // 数组指针
	p = arr;
	printf("sizeof(p) %d\n", sizeof(p));
	printf("sizeof(arr) %d\n", sizeof(arr));
	int i = 0, j = 0;
	for(i = 0; i < 6; i++) {
		printf("%p\t", *p + i);
		printf("%d\n", *(*p + i));
	}

	return 0;
}
