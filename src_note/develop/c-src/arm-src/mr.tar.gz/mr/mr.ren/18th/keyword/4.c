#include <stdio.h>


int main()
{
	volatile int i = 0x10;
	i = 0x100;
	i = 0x1000;
	i = 0x10000;
	i = 0x100000;
	printf("%x\n", i);
	return 0;
}





