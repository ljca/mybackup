#include <stdio.h>

int main()
{
	int i = 0;
	int sum = 0;
	while(i < 101)	{
		sum += i; // sum = sum + i
		i++;
	}

	printf("sum is %d\n", sum);

	return 0;
}




