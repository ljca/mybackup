#include <stdio.h>

int main()
{
	int i = 0x11223344;
	short *s = (short *)&i;
	char *c = (char *)&i;
	printf("s = %x\n", s);
	printf("c = %x\n", c);
	printf("*s = %x\n", *s);
	printf("*c = %x\n", *c);

	return 0;
}




