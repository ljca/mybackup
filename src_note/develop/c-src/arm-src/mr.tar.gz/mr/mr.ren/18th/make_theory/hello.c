#include <stdio.h>
int a = 10;
void hello()
{
	int i = 20;
	printf("hahhahaha\n");
}

