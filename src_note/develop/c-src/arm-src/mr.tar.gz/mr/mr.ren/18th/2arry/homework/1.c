#include <stdio.h>

int main()
{
	short arr[4] = {0};
	printf("%d\n", sizeof(arr));
	printf("%d\n", sizeof(*arr));
	short (*p)[4][3][2];
	printf("%d\n", sizeof(p));
	printf("%d\n", sizeof(p[0]));
	printf("%d\n", sizeof(p[0][0]));
	printf("%d\n", sizeof(p[0][0][0]));
	printf("%d\n", sizeof(p[0][0][0][0]));

	return 0;
}
