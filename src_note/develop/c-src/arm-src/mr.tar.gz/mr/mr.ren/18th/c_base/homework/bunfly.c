#include <stdio.h>

int main()
{
	int num = 1;
	int d = 5;
	while(d--) {
		printf("d is %d\n", d);
		num = 2*(num + 1);
	//	printf("num is %d\n", num);
	}
	printf("num is %d\n", num);
	return 0;
}




