#include <stdio.h>

static int a = 10;

void hello()
{
	printf("this is hello\n");
}


