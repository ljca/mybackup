#include <stdio.h>
#include <string.h>

struct person{
	int age;
	char *name;
	char gf[20];
	void (*fp)();
};

void eat()
{
	printf("eat mian\n");
}


int main()
{
	struct person p[3];
	p[0].age = 10;
	p[0].name = "tom";
	(p + 1)->age = 20;
	p[1].name = "lucy";
	p[2].age = 30;
	p[2].name = "jack";
	printf("p address is %p\n", p);

	return 0;
}




