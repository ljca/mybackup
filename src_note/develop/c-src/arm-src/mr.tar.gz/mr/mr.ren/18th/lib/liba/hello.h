#ifndef __HELLO_H
#define __HELLO_h

#include <stdio.h>

void hello();

#endif
