#include <stdio.h>
#include <stdlib.h>

#define MALLOC(type) (type *)malloc(sizeof(type))

struct dog{
	int num;
	struct dog *next;
};

void insert_head(struct dog **head, int n)
{
	struct dog *tmp = MALLOC(struct dog);
	tmp->num = n;
	tmp->next = *head;
	*head = tmp;

	return;
}

struct dog *insert_tail(struct dog *head, int n)
{
	struct dog *h = head;
	struct dog *tail = head;
	struct dog *tmp = MALLOC(struct dog);
	tmp->num = n;
	tmp->next = NULL;
	if(NULL == h) {
		head = tmp;
	}else {	
		while(h->next) {
			h = h->next;
		}
		tail = h;
		tail->next = tmp;
	}
	return head;
}

void show(struct dog *head)
{
	printf("--------start show--------\n");
	while(head) {
		printf("num is %d\n", head->num);
		head = head->next;
	}
	printf("--------show over--------\n");
}

int main()
{
	struct dog *h = NULL;
	insert_head(&h, 10);
	insert_head(&h, 20);
	insert_head(&h, 30);
	insert_head(&h, 40);
	insert_head(&h, 50);

	show(h);
	free(h);	

	return 0;
}
