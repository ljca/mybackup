#include <stdio.h>

int hello(int a, char *p)
{
	printf("a is %d\n", a);
	printf("p is %s\n", p);
	return 20;
}

int main()
{
	int a = 100;
	char *p = "bunfly";
	int s = hello(a, p);
	printf("%d\n", s);

	return 0;
}
