#include "link.h"

struct dog *insert_head(struct dog *head, int n)
{
	struct dog *tmp = MALLOC(struct dog);
	tmp->num = n;
	tmp->next = head;

	return tmp;
}
