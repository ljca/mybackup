#include <stdio.h>

int main()
{
	int i = 0;
	int sum = 0;

	for(i = 0; i < 101; i++) 
		sum += i; // sum = sum + i
	

	printf("sum is %d\n", sum);

	return 0;
}




