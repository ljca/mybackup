#include <stdio.h>

//auto int g = 10; error
//register int g1 = 10; error

int main()
{
	unsigned int i = 0;
	signed int a = -1;
	auto char c = 'a';
	register int g1 = 10;

	printf("g1 is %d\n", g1);
	return 0;
}





