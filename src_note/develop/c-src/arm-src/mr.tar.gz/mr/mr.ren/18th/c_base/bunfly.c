#include <stdio.h>

int main()
{
	int i = 10;
	printf("sizeof(i) %d\n", sizeof(i));
	int j = 20;
	printf("&i is %p\n", &i);
	printf("*(&i) is %d\n", *(&i));
	printf("&(*(&i)) is %x\n", &(*(&i)));
	return 0;
}
