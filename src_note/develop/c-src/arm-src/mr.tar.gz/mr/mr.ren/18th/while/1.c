#include <stdio.h>

int main()
{
	int i = 0;
	int sum = 0;
loop:
	sum = sum + i;
	i++;
	if(i <= 100)
		goto loop;
	else
		goto exit;
exit:
	printf("sum is %d\n", sum);

	return 0;
}




