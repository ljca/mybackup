#include <stdio.h>

enum week {mon = 1, tue, wed, thur, fri, sat, sun} tuesday;

int main()
{
	enum week monday;
	tuesday = tue;
	monday = mon;

	printf("tuesday is %d\n", tuesday);
	printf("monday is %d\n", monday);
	monday = (enum week)5;

	return 0;
}





