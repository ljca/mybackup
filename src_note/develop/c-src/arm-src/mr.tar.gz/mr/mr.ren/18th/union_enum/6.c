#include <stdio.h>

enum week {mon = 1, tue, wed, thur, fri, sat, sun};

int main()
{
	enum week day = fri;
	int i = day % 7;
	switch(i) {
		case 1:
			printf("monday\n");
			break;
		case 2:
			printf("tuesday\n");
			break;
		case 3:
			printf("wednesday\n");
			break;
		case 4:
			printf("thurday\n");
			break;
		case 5:
			printf("friday\n");
			break;
		case 6:
			printf("saturday\n");
			break;
		case 0:
			printf("sunday\n");
			break;
		default:
			printf("error day\n");
	}

	return 0;
}





