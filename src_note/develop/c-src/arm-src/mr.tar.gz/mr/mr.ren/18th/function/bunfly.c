#include <stdio.h>
int my_atoi(char *s);
void convert(int (*a)[3], int (*b)[2]);

int main(int argc, char *argv[])
{
	int arr[2][3] = {1,2,3,4,5};
	int brr[3][2];

	int (*p)[3] = 0xbf83f4ac;
	return 0;
}

