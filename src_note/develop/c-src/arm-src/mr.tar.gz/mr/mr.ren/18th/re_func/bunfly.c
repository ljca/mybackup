#include <stdio.h>

int febo(int a)
{
	if(1 == a || 2 == a) 
	{
		return 1;
	}
	return febo(a - 1) + febo(a - 2);
}

int main()
{
	printf("%d\n", printf("a = %d\n", printf("%d\n", 10)));
	printf("febo(10) is %d\n", febo(10));
	return 0;
}






