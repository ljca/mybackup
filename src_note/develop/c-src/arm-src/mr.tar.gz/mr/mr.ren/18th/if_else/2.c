#include <stdio.h>

int main()
{
	int a = 1, b = 4;

	printf("max %d\n", a > b ? a : b); //三目运算
	return 0;
}
