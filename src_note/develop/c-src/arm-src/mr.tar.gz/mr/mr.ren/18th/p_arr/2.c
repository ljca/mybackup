#include <stdio.h> //头文件

int main()
{
	int arr[3] = {0x11223344, 0x66778899, 0xaabbccdd};
	int *p = arr;
	short *s = (short *)arr;
	printf("*s %x\n", *s);
	printf("*(s + 1) %x\n", *(s + 1));
	char *c = (char *)arr;
	printf("*c %x\n", *c);
	printf("*(c + 1) %x\n", *(c + 1));

	char **p1 = (char **)arr;
	printf("*p1 %x\n", *p1);


	return 0;
}









