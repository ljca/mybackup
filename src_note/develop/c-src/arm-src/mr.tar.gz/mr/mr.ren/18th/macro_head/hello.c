#include "hello.h"

void hello()
{
	printf("hahahhahaha\n");
}


