#include <stdio.h>
#include <string.h>

int main()
{
	char s[5][20] = {"hellosadfsadf", "world", "bunfly", "welcome", "China"};
//	char *a[5] = {"hello", "world", "bunfly", "welcome", "China"};
	char (*p)[20] = s;
	printf("%s\n", (p + 1));
	printf("%s\n", (s + 1));
	printf("%s\n", (&s[0] + 1));  // &(*s) = s
	printf("%c\n", *(*(p + 1) + 1));
	int *p1 = (int *)s; 
	printf("%s\n", p1 + 5);
	printf("%p\n", p1 + 5);
	printf("%c\n", *(p1 + 5));
	short *p2 = (short *)s;
	printf("%s\n", p2 + 20);
	char **p3 = (char **)s;
	printf("%s\n", p3 + 10);
	char *m[5] = {*p, *(p+1), p+2, p+3, p+4};
	printf("mmmmmm %c\n", *(*(m + 1) + 1));
	printf("mmmmmm %s\n", m[4]);

	return 0;
}








