#include <stdio.h>
#include <string.h>

struct person{
	int age;
	char *name;
	char gf[20];
	void (*fp)();
};

void eat()
{
	printf("eat mian\n");
}


int main()
{
	struct person p = {
		.age = 10,
		.name = "tom",
		.gf = "lucy",
		.fp = eat
	};
	p.fp();
	printf("name is %s\n", p.name);
	return 0;
}




