#include "hello.h"

void hello()
{
	printf("hahaha\n");
}
