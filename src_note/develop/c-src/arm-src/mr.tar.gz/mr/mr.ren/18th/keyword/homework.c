#include <stdio.h>
#include <string.h>

struct book {
	int price;
	char *name;
	char author[30];
};

int main()
{
	char *arr[5] = {"10 mkszy mks", "30 mzdsx mzd", "20 dxpll dxp", "8 rlsz zxc", "2 yw xm"};	
	char brr[5][20] = {0};
	struct book b[5];
	int i = 0;
	for(i = 0; i < 5; i++) {
		strcpy(brr[i], arr[i]);
		b[i].price = atoi(strtok(brr[i], " "));
		b[i].name = strtok(NULL, " ");
		strcpy(b[i].author, strtok(NULL, " "));
	}
	for(i = 0; i < 5; i++) {
		printf("= %d ", b[i].price);
		printf(" %s ", b[i].name);
		printf(" %s\n", b[i].author);
	}
	//price name author strcmp

	return 0;
}


