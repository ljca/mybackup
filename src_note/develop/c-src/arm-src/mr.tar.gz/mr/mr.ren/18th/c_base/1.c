#include <stdio.h>

int main()
{
	char str[100] = {0};
	sprintf(str, "hehehehehee\n");
	printf("hahhahahha\n");
	printf("%s", str);
	return 0;
}
