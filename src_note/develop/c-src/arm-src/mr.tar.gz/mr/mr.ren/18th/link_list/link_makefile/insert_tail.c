#include "link.h"

struct dog *insert_tail(struct dog *head, int n)
{
	struct dog *h = head;
	struct dog *tail = head;
	struct dog *tmp = MALLOC(struct dog);
	tmp->num = n;
	tmp->next = NULL;
	if(NULL == h) {
		head = tmp;
	}else {	
		while(h->next) {
			h = h->next;
		}
		tail = h;
		tail->next = tmp;
	}
	return head;
}
