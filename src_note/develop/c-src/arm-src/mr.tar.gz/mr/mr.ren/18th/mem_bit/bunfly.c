#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct dog{
	char b : 4; //位域 位段
	int a : 16;       
	short c : 8;
};
struct sss{
	unsigned  a:8; //unsigned int a
	unsigned  r:4;
	unsigned  c:3;
	unsigned  s:1;	
};

int main()
{
	struct dog d;
	printf("sizeof(struct dog) %d\n", sizeof(d));

	struct sss s;
	printf("sizeof(s) %d\n", sizeof(s));
	return 0;
}




