#include <stdio.h>
#include <string.h>

void *my_memset(void *s, int c, int len)
{
	char *p = (char *)s;	
	int i = 0;
	for(i = 0; i < len; i++) {
		*(p + i) = c;
	}

	return p;
}

int main()
{
	int i = 0x11223344;
	my_memset(&i, 0, 4);
	printf("i is %x\n", i);
	char c = '1';
	my_memset(&c, 0, 4);
	printf("c is %d\n", c);
	char crr[5] = "hell";
	my_memset(crr, 0, sizeof(crr));
	for(i = 0; i < 5; i++) {
		printf("crr[%d] %d\n", i, crr[i]);
	}
	int arr[5] = {1, 2, 3, 4, 5};
	my_memset(arr, 0, sizeof(arr));
	for(i = 0; i < 5; i++) {
		printf("arr[%d] %d\n", i, arr[i]);
	}



	return 0;
}



