#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct dog{
	int a;       
	char c[10];
	char b;
};


int main()
{
	struct dog d;
	printf("sizeof(struct dog) %d\n", sizeof(d));
	printf("&d.b %p\n", &d.b);
	printf("&d.a %p\n", &d.a);
	printf("&d.c %p\n", &d.c);
	int i = 0;
	char c = 'a';
	int a = 10;
	printf("&i %p\n", &i);
	printf("&c %p\n", &c);
	printf("&a %p\n", &a);
	return 0;
}




