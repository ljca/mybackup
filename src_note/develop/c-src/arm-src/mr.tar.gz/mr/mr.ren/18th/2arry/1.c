#include <stdio.h>

int main()
{
	int arr[3][2] = {{1, 2}, {3, 4}, {5, 6}}; 
	//int arr[3][2] = {1, 2, 3, 4, 5, 6};
	int i = 0, j = 0;
	for(i = 0; i < 3; i++) {
		for(j = 0; j < 2; j++) {
			printf("arr[%d][%d] = %d\n", i, j, *(*(arr + i) + j));
		}
	}
	for(i = 0; i < 6; i++) {
		printf("%d\n", *(*arr + i));
	}

	return 0;
}
