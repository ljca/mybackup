#include <stdio.h>

int main()
{
	char *s = "123456";
	//char s[10] = "123456";
	printf("%s\n", s);
//	int num = atoi(s);
//	printf("%d\n", num);
	printf("%d\n", *s - 48);
	printf("%d\n", *s - '0');
	printf("%c\n", *(s + 1));
	printf("%d\n", *(s + 1) - '0');

	int num = 0;
	num = 10*num + *(s + 0) - '0';
	num = 10*num + *(s + 1) - '0';
	num = 10*num + *(s + 2) - '0';
	num = 10*num + *(s + 3) - '0';
	num = 10*num + *(s + 4) - '0';
	num = 10*num + *(s + 5) - '0';
	printf("%d\n", num);
	
	return 0;
}



