#include <stdio.h>

int main()
{
	int arr[2][3]; //24
	int (*p)[2][3]; //4
	int *a[2][3]; //24
	short brr[2][3]; //12
	short (*p1)[2][3];//4
	short *b[2][3];//24
	printf("%d\n", sizeof(brr));
	printf("%d\n", sizeof(p1));
	printf("%d\n", sizeof(b));
	char crr[2][3];
	char (*p2)[2][3];
	char *c[2][3];
	return 0;
}
