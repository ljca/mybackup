#include "link.h"

void show(struct dog *head)
{
	printf("--------start show--------\n");
	while(head) {
		printf("num is %d\n", head->num);
		head = head->next;
	}
	printf("--------show over--------\n");
}
