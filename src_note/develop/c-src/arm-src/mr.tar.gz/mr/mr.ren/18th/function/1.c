#include <stdio.h>


int main(int argc, char *argv[])
{
	char ip[20] = {0};
	if(1 == argc) {
		printf("argv[0] %s\n", argv[0]);
	}
	if(2 == argc) {
		printf("argv[0] %s\n", argv[0]);
		printf("argv[1] %s\n", argv[1]);
		strcpy(ip, argv[1]);
		printf("ip is %s\n", argv[1]);
		
	}

	return 0;
}
