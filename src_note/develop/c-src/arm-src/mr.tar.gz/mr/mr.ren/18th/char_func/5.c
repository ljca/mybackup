#include <stdio.h>
#include <string.h>


int main()
{
	char s[100] = "heea sadf, sadf@1234";
	char *p = strtok(s, " .@,");
	printf("%s\n", p);
	p = strtok(NULL, ".,@ ");
	printf("%s\n", p);
	p = strtok(NULL, " ,@.");
	printf("%s\n", p);
	p = strtok(NULL, "@,. ");
	printf("%s\n", p);
	return 0;
}





