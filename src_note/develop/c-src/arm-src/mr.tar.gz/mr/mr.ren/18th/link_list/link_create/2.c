#include <stdio.h>
#include <stdlib.h>

#define MALLOC(type) (type *)malloc(sizeof(type))

struct dog{
	int num;
	struct dog *next;
};

struct dog *insert_head(struct dog *head, int n)
{
	struct dog *tmp = MALLOC(struct dog);
	tmp->num = n;
	tmp->next = head;

	return tmp;
}

void show(struct dog *head)
{
	printf("--------start show--------\n");
	while(head) {
		printf("num is %d\n", head->num);
		head = head->next;
	}
	printf("--------show over--------\n");
}

int main()
{
	struct dog *h = NULL;
	h = insert_head(h, 10);
	h = insert_head(h, 20);
	h = insert_head(h, 30);
	h = insert_head(h, 40);
	h = insert_head(h, 50);

	show(h);
	free(h);	

	return 0;
}
