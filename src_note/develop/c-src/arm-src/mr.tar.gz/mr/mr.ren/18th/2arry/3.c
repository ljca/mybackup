#include <stdio.h>

int main()
{
	int arr[3][2] = {{1, 3}, {5, 2}, {4, 6}}; 
	//int arr[3][2] = {1, 2, 3, 4, 5, 6};
	int i = 0, j = 0;
	int index_i = 0, index_j = 0;
	int max = arr[0][0];
	for(i = 0; i < 3; i++) {
		for(j = 0; j < 2; j++) {
			if(max < arr[i][j]) {
				max = arr[i][j];
				index_i = i;
				index_j = j;
			}
		}
	}
	printf("max is %d\n", max);
	printf("index_i is %d\n", index_i);
	printf("index_j is %d\n", index_j);

	return 0;
}
