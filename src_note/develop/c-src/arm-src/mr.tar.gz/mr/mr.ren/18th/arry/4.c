#include <stdio.h>

int main()
{
	int arr[8] = {10, 40, 29, 48, 50, 2, 45, 32};
	int i = 0, j = 0;
	int tmp = 0;
	for(i = 0; i < 8; i++) 
	{
		for(j = 0; j < 7 - i; j++) {
			if(*(arr + j) > *(arr + j + 1)) {
				tmp = *(arr + j);
				*(arr + j) = arr[j + 1];
				arr[j + 1] = tmp;
			}
		}
	}
	for(i = 0; i < 8; i++) {
		printf("%d\n", *(arr + i));
	}
	return 0;
}
