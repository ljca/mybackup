#include "link.h"


void find(struct dog *h, int n)
{
	printf("-------find start------\n");
	int i = 0;
	while(h) {
		i++;
		if(n == h->num) {
			printf("find num %d on %d time\n", n, i);
		}
		h = h->next;
	}	

	printf("-------find over------\n");
}




