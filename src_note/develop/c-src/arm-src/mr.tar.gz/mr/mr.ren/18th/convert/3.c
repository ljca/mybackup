#include <stdio.h>

int main()
{
	int i = 10;
	int *p = &i;
	printf("p %p\n", p);
	printf("p + 1 %p\n", p + 1);
	printf("(int)p + 1 %p\n", (int)p + 1);

	return 0;
}




