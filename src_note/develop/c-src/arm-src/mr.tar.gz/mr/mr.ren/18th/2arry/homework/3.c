#include <stdio.h>

int main()
{
	int arr[2][3] = {1, 3, 5, 2, 4, 6};
	int (*p)[3] = arr;
	int *p1 = arr;
	short *p2 = arr;
	char *p3 = arr;
	short **p4 = arr;
	char **p5 = arr;
	return 0;
}
