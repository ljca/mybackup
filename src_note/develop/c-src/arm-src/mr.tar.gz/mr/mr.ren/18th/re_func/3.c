#include <stdio.h>

int mul(int a)
{
	if(1 == a || 0 == a) 
	{
		return 1;
	}
	return a * mul(a - 1);
}

int main()
{
	int m = 0;
	m = mul(5);
	printf("m is %d\n", m);
	return 0;
}
