#include <stdio.h>

int main()
{
	int arr[3][2] = {{1, 3}, {5, 2}, {4, 6}}; 
	//int arr[3][2] = {1, 2, 3, 4, 5, 6};
	int (*p)[2]; // 数组指针
	p = arr;
	printf("sizeof(p) %d\n", sizeof(p));
	printf("sizeof(arr) %d\n", sizeof(arr));
	int (*p1)[3][2];
	return 0;
}




