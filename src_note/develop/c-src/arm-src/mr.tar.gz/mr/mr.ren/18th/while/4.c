#include <stdio.h>

int main()
{
	int i = 0;
	int sum = 0;
	do {
		sum += i; // sum = sum + i
		i++;
	} while(i < 101);	

	printf(" %d\n", sum);

	return 0;
}




