#include <stdio.h>
#include <stdlib.h>

void Log()
{
	printf("%s %s in %s on %d\n", __DATE__, __TIME__, __FILE__, __LINE__);
	int i = 0;
	for(i = 0; i < 100; i++) {
		
	}
	printf("%s %s exit %s on %d\n", __DATE__, __TIME__, __FILE__, __LINE__);
}

int main()
{
	printf("__LINE__ %d\n", __LINE__);
	printf("__DATE__ %s\n", __DATE__);
	printf("__FILE__ %s\n", __FILE__);
	printf("__TIME__ %s\n", __TIME__);
	Log();

	return 0;
}
