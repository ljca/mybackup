#include <stdio.h>

int add(int a)
{
	if(1 == a || 0 == a) 
	{
		return a;
	}
//	int sum = 0;
//	sum = a + add(a - 1); //sum = sum + add(a -1)
//	return sum;
	return a + add(a - 1);
}

int main()
{
	int sum = 0;
	sum = add(100);
	printf("sum is %d\n", sum);
	return 0;
}
