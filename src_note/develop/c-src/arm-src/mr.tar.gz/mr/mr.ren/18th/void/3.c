#include <stdio.h>

void hello(void *v, void **v1)
{
	int *p = (int *)v;	
	printf("%d\n", *p);
	printf("v1 %p\n", v1);
	printf("*v1 %p\n", *v1);
	printf("**(int **)v1 %d\n", **(int **)v1);
}

int main()
{
	int i = 10;
	int *p = &i;
	void **v = (void **)&p;
	printf("p %p\n", p);
	printf("&p %p\n", &p);
	printf("v %p\n", v);
	printf("*v %p\n", *v);
//	printf("**v %p\n", **v); //error

	hello(&i, v);

	return 0;
}



