#include <stdio.h>

int main()
{
	int arr[5] = {10, 20, 30, 50, 80};
	int i = 0;
	printf("&i is %p\n", &i);
	printf("sizeof(i) %d\n", sizeof(i));
	printf("sizeof(arr) %d\n", sizeof(arr));
	printf("arr is %p\n", arr);
	for(i = 0; i < 5; i++) {
		printf("arr[%d] %d\t", i, arr[i]);
		printf("*(arr + %d) %d\t", i, *(arr + i));
		printf("%p\n", arr + i);
	}
	return 0;
}
