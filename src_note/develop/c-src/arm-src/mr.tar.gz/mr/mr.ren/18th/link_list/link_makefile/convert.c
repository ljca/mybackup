#include "link.h"

struct dog *convert(struct dog *h)
{
	struct dog *tmp = h;
	struct dog *t = NULL;
	while(h) {
		tmp = tmp->next;
		h->next = t;
		t = h;
		h = tmp;
	}
	return t;
}
