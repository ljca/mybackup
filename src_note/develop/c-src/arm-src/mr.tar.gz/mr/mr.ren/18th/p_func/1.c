#include <stdio.h>

void hello()
{
	printf("HELLO\n");
}


int main()
{
	int i = 10;
	int *p = &i;
	char c[10];
	char *cp = c;
	int arr[2][3];
	int (*ap)[3];
	char *brr[5];
	char **bp = brr;
	bp = &cp;
	void (*fp)();
	fp = hello; //void (*fp)() = hello;
	fp();

	return 0;
}



