#include <stdio.h>

int main()
{
	int i = 10;
	printf("sizeof(i) %d\n", sizeof(i));
	int j = 20;
	printf("+ %d\n", i + j);
	printf("- %d\n", i - j);
	printf("* %d\n", i * j);
	printf("/ %d\n", i / j);
	printf(" %d\n", i % j);
	return 0;
}
