#include <stdio.h>

char *my_strcat(char *d, char *s)
{
	int i = 0;
	while(d[i]) {
		i++;
	}		
	while(*s) {
		d[i] = *s;
		s++;
		i++;
	}
	return d;
}

int main()
{
	char dest[100] = "hello ";	
	char *s = "bunfly!";	
	char *p = my_strcat(dest, s);
	printf("%s\n", dest);
	printf("%s\n", p);

	return 0;
}

