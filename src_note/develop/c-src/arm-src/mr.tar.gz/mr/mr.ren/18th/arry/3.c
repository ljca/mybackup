#include <stdio.h>

int main()
{
	int a = 90;
	int arr[5] = {10, 40, 29, 48, 50};
	int i = 0;
	int max = arr[0];
	int index = 0;
	int tmp = 0;
	for(i = 0; i < 4; i++)
	{
		if(max < *(arr + i + 1)) {
			tmp = max;
			max = *(arr + i + 1);
			arr[i + 1] = tmp;
			index = i + 1;
		}
	}

	printf("max is %d\n",  max);
	printf("index is %d\n",  index);
	return 0;
}
