#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct dog{
	char b : 4; //位域 位段
	int a : 16;       
	short c : 8;
};


int main()
{
	struct dog d;
	printf("sizeof(struct dog) %d\n", sizeof(d));
	return 0;
}




