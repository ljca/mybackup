#include <stdio.h>

int main()
{
	int arr[5] = {0xaabbccdd, 0x11223344, 0x55776688};
	printf("sizeof(arr) %d\n", sizeof(arr));
	short srr[5] = {0x3344, 0xbbff, 0xccdd, 0x1122};
	printf("sizeof(srr) %d\n", sizeof(srr));
	char crr[5] = {'a', '1', '@', '!', 'c'};
	printf("sizeof(crr) %d\n", sizeof(crr));
	char str[10] = {"123456789"};
	char str1[10] = "hello";
	return 0;
}
