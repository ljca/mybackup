#include <stdio.h>

int main()
{
	char c = 'a';
	char b = '1';
	printf("%c\n", c);
	printf("%c\n", b);
	printf("%d\n", c);
	printf("%d\n", b);
	int a = 1;
	printf("%d\n", a + c);
	printf("%d\n", a + b);
	printf("%c\n", a + c);
	printf("%c\n", a + b);
	return 0;
}
