#include <stdio.h>

int main()
{
	int i = 97;
	char c = i; //隐式的转换
//	char c = (char)i;
	printf("i is %d\n", i);
	printf("c is %c\n", c);
	int *p = &i;
	char *p1 = (char *)&i; //显示 
	printf("*p1 is %c\n", *p1);

	return 0;
}




