#ifndef __HELLO_H //防止头文件被重复包含
#define __HELLO_H

#include <stdio.h>

//int a = 10; error
void hello();
void show();
int add(int a, int b);

#endif //__HELLO_H

