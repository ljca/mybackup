#include <stdio.h>
#include <stdlib.h>

#define MALLOC(type) (type *)malloc(sizeof(type))

struct dog{
	int num;
	struct dog *next;
};

struct dog *insert_head(struct dog *head, int n)
{
	struct dog *tmp = MALLOC(struct dog);
	tmp->num = n;
	tmp->next = head;

	return tmp;
}

struct dog *insert_tail(struct dog *head, int n)
{
	struct dog *h = head;
	struct dog *tail = head;
	struct dog *tmp = MALLOC(struct dog);
	tmp->num = n;
	tmp->next = NULL;
	if(NULL == h) {
		head = tmp;
	}else {	
		while(h->next) {
			h = h->next;
		}
		tail = h;
		tail->next = tmp;
	}
	return head;
}

void show(struct dog *head)
{
	printf("--------start show--------\n");
	while(head) {
		printf("num is %d\n", head->num);
		head = head->next;
	}
	printf("--------show over--------\n");
}

void find(struct dog *h, int n);

int main()
{
	struct dog *h = NULL;
	h = insert_tail(h, 10);
	h = insert_tail(h, 20);
	h = insert_head(h, 30);
	h = insert_tail(h, 40);
	h = insert_tail(h, 10);
	h = insert_head(h, 50);
	h = insert_head(h, 10);

	show(h);
	find(h, 10);
	free(h);	

	return 0;
}


void find(struct dog *h, int n)
{
	printf("-------find start------\n");
	int i = 0;
	while(h) {
		i++;
		if(n == h->num) {
			printf("find num %d on %d time\n", n, i);
		}
		h = h->next;
	}	

	printf("-------find over------\n");
}




