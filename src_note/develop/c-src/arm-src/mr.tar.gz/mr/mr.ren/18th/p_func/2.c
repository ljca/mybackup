#include <stdio.h>

int add(int a, int b)
{
	return a + b;
}

int call(int (*fp)(int, int))
{
	return fp(20, 20);
}


int main()
{
	int i = 10;
	int *p = &i;
	
	int sum = add(10, 20);
	printf("sum is %d\n", sum);
	int (*fp)(int, int) = add;
	printf(" %d\n", fp(11, 22));
	//sum = call(fp);
	sum = call(add);
	printf("sum is %d\n", sum);

	return 0;
}



