#include <stdio.h>


union u_dog{
	int a;
	int b;
};

int main()
{
	int tmp = 0;
	union u_dog ud;
	printf("&ud.a is %p\n", &ud.a);
	printf("&ud.b is %p\n", &ud.b);
	ud.a = 10;
	tmp = ud.a;
	ud.b = 20;

	int sum = tmp + ud.b;
	printf("sum is %d\n", sum);
	return 0;
}





