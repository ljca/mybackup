#include <stdio.h>

int main()
{
	int a = 36;
	int b = 48;
#if 0
	int max = 0;
	for(max = b; max > 0; max--) {
		if(0 == a % max && 0 == b % max) {
			printf("max is %d\n", max);
			break;
		}
	}
#else
	int tmp = 0;
	while(a % b) {
		tmp = a;
		a = b;
		b = tmp % b;
	}
	printf("max is %d\n", b);
#endif
	return 0;
}




