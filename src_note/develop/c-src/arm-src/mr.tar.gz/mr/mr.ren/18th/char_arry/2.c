#include <stdio.h>
#include <string.h>

int main()
{
	char str[20] = "hello world";
	*str = *str - 32;
	*(str + 6) = 'W';
	printf("%s\n", str);
	printf("str + 6 %p\n", str + 6);

	char *s = "hello world";
	printf("s %p\n", s);
//	*s = *s - 32; error 只读区无法修改
	printf("%s\n", s);

	return 0;
}
