#include <stdio.h>
#include <string.h>

int main()
{
	char str[20] = {0};
	char *s = "hello world";
	char *p = str;
	while(*s) {
		*p = *s;
		s++;
		p++;
	}
	printf("str %s\n", str);
	return 0;
}
