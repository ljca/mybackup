#include <stdio.h>

void hello() //定义
{
	printf("this is hello\n");
	return;
}

int hello1(); //声明

int main(int argc, char *argv[])
{
	hello();
	int sum = hello1();
	printf("sum is %d\n", sum);
	return 0;
}

int hello1() //定义
{
	int a = 100;
	int b = 200;
	return a + b;
}
