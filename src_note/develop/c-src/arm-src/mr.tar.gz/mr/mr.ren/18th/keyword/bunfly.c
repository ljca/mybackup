#include <stdio.h>

extern int a;
extern void hello();

int main()
{
	hello();
	printf("a is %d\n", a);
	return 0;
}





