#include <stdio.h>

int main()
{
	int i = 10;
//	void v = 10; //error
	void *p = &i;
	int *p1 = &i;
	printf("sizeof(p) %d\n", sizeof(p));
	printf("*p1 %d\n", *p1);
	printf("sizeof(*p1) %d\n", sizeof(*p1));
	//printf("*p %d\n", *p); error
	printf("*((int *)p) %d\n", *((int *)p)); 
	

	return 0;
}
