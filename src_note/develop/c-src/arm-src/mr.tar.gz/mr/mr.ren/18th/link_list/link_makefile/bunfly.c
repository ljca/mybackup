#include "link.h"

int main()
{
	struct dog *h = NULL;
	h = insert_tail(h, 70);
	h = insert_tail(h, 20);
	h = insert_tail(h, 10);
	h = insert_tail(h, 40);
	h = insert_tail(h, 30);
	h = insert_tail(h, 60);
	h = insert_tail(h, 50);
	
	show(h);
	printf("---------convert--------\n");
	h = convert(h);

	show(h);
	printf("---------find--------\n");
	find(h, 10);
	h = sort(h);
	show(h);
	free(h);	

	return 0;
}

