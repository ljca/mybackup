#include <stdio.h>
#include <stdlib.h>

#define FOREVER while(1)
#define SAY printf("hello\n")

int main()
{
	FOREVER SAY;
	return 0;
}
