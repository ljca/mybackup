#include <stdio.h>

void hello()
{
	int i = 0;
	i++;
	printf("i = %d\n", i);
}
void hello1()
{
	static int a = 0;
	a++;
	printf("a = %d\n", a);
}

int main()
{
	int i = 5;
	while(i--) {
		hello();
		printf("-----------hello1--------\n");
		hello1();
	}
	return 0;
}





