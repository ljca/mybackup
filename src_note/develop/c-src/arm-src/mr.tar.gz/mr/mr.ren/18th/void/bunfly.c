#include <stdio.h>
#include <string.h>

int main()
{
	int i = 0x11223344;
	memset(&i, 0, 4);
	printf("i is %x\n", i);
	char c = '1';
	memset(&c, 0, 4);
	printf("c is %d\n", c);
	char crr[5] = "hell";
	memset(crr, 0, sizeof(crr));
	for(i = 0; i < 5; i++) {
		printf("crr[%d] %d\n", i, crr[i]);
	}
	int arr[5] = {1, 2, 3, 4, 5};
	memset(arr, 0, sizeof(arr));
	for(i = 0; i < 5; i++) {
		printf("arr[%d] %d\n", i, arr[i]);
	}



	return 0;
}



