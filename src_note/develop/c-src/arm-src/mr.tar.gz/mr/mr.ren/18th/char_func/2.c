#include <stdio.h>
#include <string.h>

int main()
{
	char dest[20] = "hello";
	char *src = "bunfly";
	char *p = strcat(dest, src);

	printf("%s\n", p);
	printf("%s\n", dest);


	return 0;
}


