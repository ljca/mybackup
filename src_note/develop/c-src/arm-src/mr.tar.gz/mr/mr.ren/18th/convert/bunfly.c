#include <stdio.h>

int main()
{	
	int a[5] = {1, 2, 3, 4, 5};
	int (*p)[5] = &a;
	printf("a %p\n", a);
	printf("p + 1 %p\n", p + 1);
	int *p1 = (int *)(&a + 1); //(int *)(p + 1)
	printf("%d\n", *(p1 - 1));//p1[-1]
	int *p2 = (int *)((int)a + 1);
	printf("p2 %p\n", p2);
	printf("%x\n", *p2);

	return 0;
}




