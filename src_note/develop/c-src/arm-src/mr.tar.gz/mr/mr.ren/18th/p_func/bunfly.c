#include <stdio.h>

int add(int a, int b)
{
	printf("add  ");
	return a + b;
}

int call(int (*fp)(int, int))
{
	return fp(20, 20);
}

int hello(int a, int b)
{
	printf("this is hello %d\n", a + b);
	return 100;
}

int (*call1(int (*fp)(int, int), int a, int b))(int m, int n)
{
	printf("call1 %d\n", fp(a, b));
	return hello;
}


int main()
{
	int (*fp)(int, int) = call1(add, 11, 77);	
	fp(10, 20);
	int s = hello(1, 2);
	printf("s %d\n", s);
	return 0;
}



