#include <stdio.h>

int main()
{
	int a = 10, b = 20;
	
	if(-1) {
		printf("a < b\n");
	}else
		printf("hhhahahaha\n");
	return 0;
}
