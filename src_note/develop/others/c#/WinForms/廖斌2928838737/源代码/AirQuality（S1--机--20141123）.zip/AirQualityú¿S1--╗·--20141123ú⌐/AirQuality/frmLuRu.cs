﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AirQuality
{
    public partial class frmLuRu : Form
    {
        public frmLuRu()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        //清空所有
        private void btnQingKong_Click(object sender, EventArgs e)
        {
            //方式一：逐一清空
            this.txtEndDate.Clear();
            this.txtInputName.Text = "";
            this.txtLevel.Text = "";
            this.txtNotes.Text = "";
            this.txtPM.Text = "";
            this.txtStartDate.Text = "";
            //方式二：使用循环遍历
            foreach (Control item in this.Controls)
            {
                if (item is TextBox)
                {
                    //完成清空操作
                    item.Text = "";
                    //((TextBox)item).Clear();
                }
            }

        }
        //关闭
        private void btnGuanBi_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //提交
        private void btnTiJiao_Click(object sender, EventArgs e)
        {
            //校验用户录入数据是否完整
            if (this.cboStationID.Text == "" ||
                this.txtEndDate.Text.Length == 0 ||
                this.txtInputName.Text.Length < 1 ||
                string.IsNullOrEmpty(this.txtLevel.Text)||
                this.txtNotes.Text == string.Empty ||
                this.txtPM.Text == "" ||
                this.txtStartDate.Text == "" )
            {
                MessageBox.Show("所有信息均不能为空！请完善!");
                return;
            }
            //再提交到数据库
            try
            {


                //提示
                MessageBox.Show("数据已经成功保存！","操作提示");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show("数据库操作失败！");
            }

        }
        //查询，所有的检测站信息
        private void frmLuRu_Load(object sender, EventArgs e)
        {
            try
            {
                //显示所有的

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
