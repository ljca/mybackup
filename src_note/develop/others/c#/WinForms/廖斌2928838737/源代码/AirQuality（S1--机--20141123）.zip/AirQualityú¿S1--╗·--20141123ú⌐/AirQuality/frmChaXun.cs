﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AirQuality
{
    public partial class frmChaXun : Form
    {
        public frmChaXun()
        {
            InitializeComponent();
        }
       
        //查询所有的检测记录
        private void frmChaXun_Load(object sender, EventArgs e)
        {
            try
            {
                //显示所有的

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //模糊查找
        private void btnChaZhao_Click(object sender, EventArgs e)
        {
            try
            {
                //显示所有的

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        //关闭
        private void btnGuanBi_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
