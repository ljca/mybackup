/* $Id$
 * yo.c - Code to demonstrate RCS usage
 */
#include <stdio.h>

int main(void)
{
	printf("yo, Linux programmer!\n");
	return 0;
}
