/*
 * helper.c - Helper code for howdy.c
 */

#include <stdio.h>
#include "helper.h"

void msg(void)
{
	printf("This message sent from Jupiter.\n");
}
