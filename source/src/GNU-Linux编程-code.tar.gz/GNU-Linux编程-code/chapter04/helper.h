/*
 * helper.h - Header for helper.c
 */
void msg(void);
