/*
 * hello.c - Canonical "Hello, World!" program
 */
#include <stdio.h>

int main(void)
{
	printf("Hello, Linux programming world!\n");
	return 0;
}

