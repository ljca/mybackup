/* Define this 1 if your compiler allows a (void *) function return */
#define HAVE_VOID_POINTER 0

/* Define this  1 if your C compiler has a short_short_t type */
#define short_short_t 0

/* Define this 1 if your signal handling library support sys_siglist */
#define HAVE_SYS_SIGLIST 0
