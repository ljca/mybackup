// Component.cpp
//

#include <X11/Intrinsic.h>
#include "Component.hxx"

Component::Component() {
   my_widget = (Widget)NULL;
}
