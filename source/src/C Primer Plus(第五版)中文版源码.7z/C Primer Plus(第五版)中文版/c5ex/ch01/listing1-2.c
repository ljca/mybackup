#include <stdio.h>
int main(void)
{
    printf("Concrete contains gravel and cement.\n");
    
    return 0;
}
