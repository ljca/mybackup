#!/bin/bash - 
#===============================================================================
#
#          FILE: genara.sh
# 
#         USAGE: ./genara.sh 
# 
#   DESCRIPTION: 
# 
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: YOUR NAME (), 
#  ORGANIZATION: 
#       CREATED: 2017年02月23日 20:52
#      REVISION:  ---
#===============================================================================
shopt -s direxpand
shopt -s cdspell
#shopt -s dirspell

