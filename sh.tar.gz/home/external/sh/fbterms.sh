#!/bin/bash - 
LANG="zh_CN.UTF-8" exec fbterm
