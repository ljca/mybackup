export LESSOPEN='|/usr/bin/lesspipe.sh %s'
