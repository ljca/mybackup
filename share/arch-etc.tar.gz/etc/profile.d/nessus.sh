export PATH=$PATH:/opt/nessus/bin:/opt/nessus/sbin
