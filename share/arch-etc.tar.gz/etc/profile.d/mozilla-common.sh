export MOZ_PLUGIN_PATH="/usr/lib/mozilla/plugins"
